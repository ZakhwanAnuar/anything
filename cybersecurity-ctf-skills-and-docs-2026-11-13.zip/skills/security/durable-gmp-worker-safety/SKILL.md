---
name: durable-gmp-worker-safety
description: Use when building durable managed GMP scan workers.
version: 0.1.0
author: VAS project contributors, Hermes Agent
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [greenbone, durable-workers, crash-reconciliation, safety]
    related_skills: []
---

# Durable GMP worker safety

## When to use
- Implement or review a database-backed managed Greenbone scan worker.
- Reconcile remote resource creation, start, stop or completed-report ingestion after crashes.

## Procedure
1. Inspect the installed python-gvm public signatures/source with `terminal` and read the matching official GMP API documentation; accept only a verified protocol version. Do not infer commands from other protocol versions.
2. Hold a dedicated PostgreSQL session advisory lock, verify its backend PID and actual pg_locks ownership before mutation, and latch connection/lock loss. Invalidate possibly still-locked connections instead of returning them to the pool.
3. Commit each remote mutation intent before issuing it. Recover lost creations only through a unique server-declared exact job marker, ownership and scope readback. A committed ambiguous start must never be resent; New is not proof it never started.
4. Pin all authorized DNS answers in a bounded killable subprocess, revalidate current policy and actor before start, reject rebinding and ambiguous IPv4-mapped IPv6 targets, and send only literal addresses with reverse lookup disabled.
5. Verify exact owned task/target/config/scanner/port-list identities immediately before start or stop. Keep resource snapshots and never automatically delete resources.
6. Bound bytes and elapsed time before upstream XML accumulation. Screen DTD/entity declarations before its parser sees them; retain an accumulated suffix across arbitrarily small reads, not merely the last chunk. Then apply defused XML and structural limits.
7. Reconcile owned status before cancellation. Commit stop intent once, poll actual Stopped without importing partial reports, and let verified Done win a completion-versus-stop readback race.
8. Validate every native report host, including scanner-error rows and inventory. Require exact task/report identity, Done, declared completeness and a dated scan end. Ingest findings, observations, import identity, job completion and worker audit atomically with the caller-owned transaction.
9. Publish readiness independently from progress/control: a successful poll is not evidence of ready feeds. A readiness failure must not prevent safe stopping or completion reconciliation.

## Pitfalls
- Do not hold ORM transactions or row locks across DNS/GMP calls.
- Do not deduplicate managed reports solely by XML wrapper bytes; bind semantic scanner report identity and reject conflicting prior imports.
- Do not claim scanner readiness, coverage or security from fake transports or zero findings.
- Do not use SQLite as a production lock substitute. Require an explicit injected offline fake seam and keep it off the CLI.

## Verification
Use `terminal` to exercise a crash matrix before/after intent commits, remote effects and identity/completion commits. Include cancellation races, lock loss, ownership mutation, malformed metadata, duplicate markers, DNS rebinding, full host-scope checks and actual observation rollback. Run optional real PostgreSQL lock checks only against an explicitly supplied disposable database; report skips honestly. Never touch retained application databases or live scanners merely to improve test coverage.
