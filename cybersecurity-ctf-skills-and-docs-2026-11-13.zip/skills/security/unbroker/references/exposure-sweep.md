# Exposure sweep - what is out there on an email, name, or phone

Phase 1 of unbroker maps the **broker** databases. This file covers the rest of a person's public
footprint: breach corpora, account registrations, code/paste/certificate leaks, document hosts, and
social profiles. Run it when the operator says "find what is spreading with this email" (no removal
yet), when the subject is outside the US so the broker lane is near-empty, or before deciding which
removals are worth doing.

Everything here is read-only. Removal still needs recorded consent (see SKILL.md), and research that
is going to lead to a request is subject to the same gate.

## Order of operations

Cheapest and highest-signal first; each line returns something you can act on.

1. **Breach exposure.** XposedOrNot answers keyless:
   `curl -s https://api.xposedornot.com/v1/check-email/<email>` for the site list and
   `curl -s "https://api.xposedornot.com/v1/breach-analytics?email=<email>"` for exposed data classes
   and a risk score. Have I Been Pwned's API needs a paid key (unauthenticated returns 401), and
   emailrep.io now refuses unauthenticated calls - do not report either as "clean".
   Read the exposed-data classes, not just the site names: a stealer-log entry (plaintext passwords)
   outranks everything else in the report and means credential rotation comes first, before any
   broker opt-out. Names/DOB/IP/geo in a breach feed the same identity-matching as a broker listing.
2. **Account registrations by email.** `holehe --only-used <email>` checks ~120 services in seconds
   and lists where the address is registered. This is registration, not exposure - but it tells the
   operator which accounts exist and which of them are public profiles.
3. **Identifiers derivable from the address.** Gravatar: `curl -s -o /dev/null -w '%{http_code}'
   https://www.gravatar.com/avatar/<md5-of-email>?d=404` (404 = no profile) and
   `https://www.gravatar.com/<md5>.json` for the profile body. Certificate Transparency:
   `curl -s "https://crt.sh/?q=<email>&output=json"` finds the address in cert identities.
4. **Public code.** Sourcegraph accepts an anonymous stream query:
   `curl -s -G --data-urlencode 'q=context:global "<email>"' https://sourcegraph.com/.api/search/stream -H 'Accept: text/event-stream'`
   - parse `event: matches` blocks and check `matchCount`. GitHub code search needs a token
   (unauthenticated 401) and grep.app sits behind a JS checkpoint, so reach those with the browser
   tools instead. Absence here is a real negative worth stating.
5. **Handle enumeration.** `sherlock <handle>` / `maigret <handle> -J simple` on the email local part.
   Treat every hit as unverified - see the false-positive rule below.
6. **Verify the leads that matter, in the browser.** An X profile renders the display name for a
   logged-out viewer even when the HTML shell is empty, so `x.com/<handle>` is the cheapest way to
   turn a handle into a real name - and a handle that equals the email local part whose display name
   equals a name the operator gave you is the strongest email-to-person link obtainable without
   logging in. Do the same for TikTok (its shell is empty to plain fetches). LinkedIn public profiles
   answer with a login modal: dismiss it once, then the snapshot still carries the headline, location,
   school, and recent activity.
7. **Local-jurisdiction document hosts.** School, university, and government rosters leak into
   flipbook and document hosts, where they are fully indexed: search `"<full name>" anyflip OR scribd`
   and the name plus student/registration number. A roster row giving name + national student number +
   home address is third-party PII in someone else's upload - the removal path is a takedown request
   to the uploader and the host, not a broker opt-out, and it usually covers dozens of unrelated
   minors, so report the row, not the whole document. Search-engine snippets of those documents count
   as evidence even when the page itself is login- or paywall-gated; say which one it was.
8. **Phone numbers as identifiers.** Number lookups mostly return junk SEO farms that scrape number
   ranges into fake recruitment pages. Report those as noise rather than as the person's exposure,
   and never as a data-broker listing.

## False-positive rule for handle hits

A username-enumeration "hit" whose page title is the service's generic home page, a bot wall, or a
sub-200-byte stub is **not an account**. Verify with a title/size check before it enters the report:

```sh
curl -s -m 20 -o /tmp/p.html -w '%{http_code} %{size_download} ' -L -A 'Mozilla/5.0 ...' "$url"
```

Discard the hit when the title is boilerplate ("GIFs on GIPHY - Be Animated", the site's own name) or
the body is a stub, and say so in the report - a short "discarded as lookalikes" list is worth more
than a padded findings list. Anything that survives goes in as "same handle, identity unverified"
unless a display name, avatar, or the email itself appears on the page.

## Report shape

Group findings so the operator can act without re-deriving anything:

1. **Verified links** between the address and the person (handle equals local part, display name equals
   a supplied alias), each with the URL and what made it verified.
2. **Third-party documents** holding the name/ID, with the host, the uploader where visible, and the
   removal route (uploader, host takedown, or institution).
3. **Account registrations** (email-keyed), marked as accounts rather than exposure.
4. **Breach exposure** with the exposed data classes and the credential-rotation action first.
5. **Explicit negatives** - what was checked and came back clean, so the operator knows the sweep was
   real. Negative claims require the source to have actually answered; a refused or key-gated API is
   "not checked", not "clean".
6. **Discarded false positives**, one line each.

Mark evidence quality per finding (own page vs search snippet vs login-gated) and never upgrade a
snippet to a verified page.
