---
name: infostealer-account-recovery
description: Use when an infostealer hit and accounts must be secured.
version: '1.0'
author: hermes
license: Apache-2.0
metadata:
  hermes:
    tags:
    - incident-response
    - credential-theft
    - account-recovery
    - browser-forensics
    - 2fa
    related_skills:
    - analyzing-linux-system-artifacts
    - performing-service-account-credential-rotation
    - implementing-passwordless-authentication-with-fido2
---

# Infostealer account recovery

## When to use
A PC was hit by an infostealer / stealer log / "all my passwords are leaked", or the user asks you to find and
secure every account they own. Also applies to any "enumerate all my accounts" request.

## The one rule that everything else follows

A stealer takes **saved passwords AND browser cookies**. Cookies are live session tokens. **Changing a password does
not evict an attacker holding a session cookie.** Always order:

```
CONTAIN -> REVOKE all sessions -> CHANGE password -> RE-ENROL 2FA -> NEW backup codes ->
AUDIT (app passwords, OAuth grants, forwarding/rules, recovery email+phone, delegates) -> MIGRATE to password manager
```

Doing it backwards hands the attacker the new password. Migration to a password manager comes **last**, from a
verified-clean device - a manager does not protect a still-infected machine (keylog at unlock + vault exfil).

## Hard boundaries - say these out loud to the user

- **Never log into the user's accounts, and never accept a password / 2FA code / recovery code in chat.** Account
  changes are the user's to perform. You find, order, and instruct.
- Never print a secret VALUE into a report. Identifiers (emails, usernames, handles, SteamID, domains), file paths,
  counts and timestamps only. Say "auth token present in <path>", never the value.
- Read-only forensics. Preserve evidence; do not delete/quarantine/kill/install. Never execute a suspicious file.

## Step 1 - inventory the credential surface (before advising anything)

- **Browsers.** Chromium family (`Login Data` -> `logins` table has plaintext `origin_url`/`username_value`; password
  column encrypted, don't touch it), Firefox `logins.json` (hostname + timeCreated plaintext, credentials encrypted),
  `cookies.sqlite` / `Cookies` for live-session hosts, `formhistory.sqlite`, `places.sqlite` for login/account URLs
  (catches accounts with no saved password). Check whether a **Primary Password** is set - if not, saved logins were
  offline-decryptable.
- **OS keyring.** `~/.local/share/kwalletd/kdewallet_attributes.json` reveals entry NAMES in plaintext (e.g.
  `Chromium Keys/Chromium Safe Storage` = the key decrypting all Chromium passwords; `Secret Service/Password for
  'X' on 'Y'`). GNOME equivalents in `~/.local/share/keyrings`. Cheap and high-signal.
- **Launchers/games.** Steam `loginusers.vdf` + `config.vdf` (token store), Heroic `legendaryConfig`/`gog_store`/
  `nile_store`, Roblox `.ROBLOSECURITY`, Discord leveldb token, Telegram `tdata`, Ubisoft `user.dat`.
- **Dev/cloud/AI.** `~/.hermes/.env` and `.env` trees, `~/.hermes/auth.json`, `~/.codex/auth.json`,
  `~/.cli-proxy-api/`, `~/.config/{Claude,mulerun,gh,gcloud,aws}`, `.npmrc`/`.pypirc`/`.cargo/credentials.toml`,
  `~/.ssh`, `.git-credentials`.
- **Plaintext junk in `~/Downloads` / `~/Documents` / `~/Desktop`.** Recovery-code and recovery-phrase files are the
  highest-value find and users always have them. Sweep `*password*`, `*recovery*`, `*backup*code*`, `*2fa*`, `*seed*`,
  `*secret*`, `*.kdbx`. **Check filenames that ARE the password** (e.g. a tiny file named `BZBU22@L1ghT_Y3ar`).

Batch this across parallel subagents (browsers / gaming / dev-cloud / identity / forensics / runbook / plan), each
writing its own report file and returning a condensed summary.

## Step 2 - verify which machine is actually infected

Ask. Then check whether the other machine's data reached this one - **Firefox Sync is the usual leak path**:
`signedInUser.json`, `prefs.js` for `services.sync.*`, `lastSync`, populated `loginsL/M/SyncMeta` tables, a
`storage-sync-v2.sqlite`, and discontinuous date bursts in `places.sqlite`. If Sync is off and never completed, the
profiles are independent and this host is safe to use as the trusted device.

## Step 3 - build the recovery-dependency graph (highest-value analysis)

Do not hand over a flat account list. Find the **single point of failure** - usually the primary email, which is
simultaneously the mailbox, the owning address of the browser-sync account, and the "Sign in with Google" provider.
Output a top-down "secure in this order" chain:

```
Phone/SIM -> primary Gmail -> secondary Gmail -> recovery Gmail -> Proton/vault -> MS/Zoho/OpenAI ->
           money & government -> work/reputation -> social/gaming -> throwaways
```

The password manager's own account is the crown jewel - if its recovery phrase was sitting in plaintext, it is
burned; secure that account before using the vault to rotate anything else.

## Step 4 - mark burn-and-regenerate, not just change

Anything found in plaintext on disk gets **regenerated**: 2FA backup codes, account recovery phrases, GOG/Steam
redeem codes, app-specific passwords. State the rule: `~/Downloads` and `~/Desktop` are first-pass stealer targets -
nothing sensitive lives there.

## Step 5 - deliver three artifacts, not one

1. **Rotation runbook** - per-provider, ordered by blast radius, checkbox per provider, time estimate each.
   Service-specific gotchas: Google device-activity + app passwords + Gmail filters/"send mail as"; Microsoft
   **inbox rules** (attackers add auto-delete/forward rules); Discord authorised apps + **regenerate backup codes**;
   Telegram terminate all other sessions; Steam deauthorize all devices + check `/dev/apikey` for a rogue API key.
2. **Password-manager + 2FA plan** - harden what they already use before proposing a switch; primary email and bank
   stay multi-path (hardware key + TOTP + codes) so a lost key is not a lockout. Insist on **two** hardware keys
   before any key-only enrolment.
3. **Windows collector** if the victim is Windows - read-only PowerShell dumping Defender detection history (names
   the family), Run keys, scheduled tasks, services, WMI subscriptions, browser saved-login **hosts** (origin_url +
   username only), app session stores, recent/hidden binaries with Authenticode status, connections, DNS cache,
   local admins. Zip the output for analysis.

## Pitfalls
- All-flatpak hosts put browser profiles under `~/.var/app/<app-id>/` - `~/.mozilla` and `~/.config/google-chrome`
  come back empty and make you think no browser exists. Run `flatpak list` early.
- Copy SQLite files to scratch before querying; running browsers hold locks and `immutable=1` can hide WAL rows.
- Firefox `localStorage` values are LZ4-compressed; a raw-byte sweep still catches emails the decoder misses.
- Do not report the user's own infrastructure (agents, gateways, MCP servers, containers) as malware.
- On atomic/immutable distros you cannot remediate; an `rpm-ostree` rebase plus wiping `$HOME` dotfiles is more
  honest than chasing userland persistence.
- For the infected host: **reimage beats clean** for a stealer - the stealer runs for seconds but its dropper and any
  secondary payload may persist.
- Verify child reports afterwards: grep them for secret-shaped patterns (`sk-`, `AIza`, `ghp_`, `AKIA`, JWTs,
  `BEGIN ... PRIVATE KEY`, 40+ hex). A leaked secret in a report file is a second incident.
