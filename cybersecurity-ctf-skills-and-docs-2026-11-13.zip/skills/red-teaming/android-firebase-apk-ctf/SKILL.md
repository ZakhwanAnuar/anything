---
name: android-firebase-apk-ctf
description: "Use when a CTF APK uses Firebase: flags in code/traffic/DB."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux]
metadata:
  hermes:
    tags: [ctf, mobile, android, firebase, reversing, apk]
---

# Android + Firebase APK CTF Playbook

Use when an Android CTF challenge APK contains Firebase (look for
`com.google.firebase` in the manifest/dex, or Firebase strings in
`res/values/strings.xml`). A common 3-challenge chain: (1) reverse the app for
a flag, (2) "capture"/intercept the Firebase traffic for flag 2, (3) read the
Firebase DB for flag 3.

## 1. Decompile
```bash
mkdir -p ~/ctf/<event>/<challenge>/ && cd $_
cp ~/Downloads/<name>.apk .
jadx -d jadx_out Pukimon.apk --no-res        # note: use ABSOLUTE paths (Kali wrapper chdirs)
apktool d -f -o apktool_out Pukimon.apk     # gives res/values/strings.xml decoded
unzip -o Pukimon.apk -d apk_unz             # raw files incl. resources.arsc
```
- App logic is usually in `MainActivityKt` / `MainActivity` (Compose apps:
  strings, base64 blobs, hex comparisons, Firebase calls).
- Check `res/values/strings.xml` for Firebase config:
  `project_id`, `google_app_id`, `google_storage_bucket`, `google_api_key`.

## 2. Identify the Firebase backend
- Default RTDB URL: `https://<project_id>-default-rtdb.firebaseio.com`
  (also `<project>-default-rtdb.<region>.firebasedatabase.app`).
- Probe unauthenticated REST: `curl <db>/.json`, `<db>/<path>.json`,
  `<db>/.settings/rules.json` (rules exposure), write probes (PUT/POST).
- `401 Permission denied` = rules require auth. `404` = wrong host/region.
- The app signs in anonymously: `FirebaseAuth.getInstance().signInAnonymously()`.

## 3. Anonymous auth via REST (when you have a working API key)
```bash
KEY="AIzaSy..."
curl -s -X POST "https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=$KEY" \
  -H "Content-Type: application/json" -d '{"returnSecureToken":true}'
# -> idToken ; then:
curl -s "https://<project>-default-rtdb.firebaseio.com/.json?auth=$TOKEN"
```
- Also try `securetoken.googleapis.com/v1/token` for refresh flows.
- Wrong key error: `API key not valid` — key is redacted/revoked.

## 4. When the API key is redacted in the handout
Common: `google_api_key` ships as `AIzaSy...Ycss` (prefix+suffix kept, middle
stripped) — the app cannot auth with it.
- Verify at byte level: `python3 -c "d=open('resources.arsc','rb').read(); print(d[d.find(b'AIza'):][:60])"`
- Check whether the platform-served original differs:
  `unzip -p Pukimon.zip Pukimon.apk | sha256sum` vs handout hash.
- RECOVER the real key from writeup screenshots: solvers often publish
  HTTP Toolkit / Burp captures of `securetoken.googleapis.com/v1/token?key=...`.
  - Grab the original image from HackMD uploads (add `-e https://hackmd.io/` referer!)
  - OCR with tesseract: upscale 4-12x (LANCZOS/NEAREST), `--psm 7`/`13`,
    threshold around 150 on grayscale; try multiple psm values; brute-force
    the ambiguous chars (B/8, O/0/Q, 5/S, v/V, 7/1, W/M, l/1/I) against
    identitytoolkit as an oracle (fast, parallel).
- If every OCR variant fails with `API key not valid`, the key was REVOKED
  post-event → live DB is unreachable. The flag values may still exist in
  writeups: search Bing (Google/DDG block bots) via scrapling stealthy fetch,
  GitHub repos/issues, HackMD, and grep.app (works in a browser, not curl).

## 5. Flag-in-traffic pattern (challenge 2)
- The RTDB read goes over a WEBSOCKET, not HTTP:
  `wss://s-<shard>.firebaseio.com/.ws?ns=<ns>&v=5&ls=<token>`
  (shard host seen in proxy captures, e.g. `s-usc1f-nss-2568.firebaseio.com`).
- Response frame: `{"t":"d","d":{"r":N,"b":{"s":"ok","d":"<FLAG>"}}}`.
- Intercept with mitmproxy/HTTP Toolkit; or read the DB directly via REST.

## 6. Flag-in-database pattern (challenge 3)
- Root dump (`GET /.json?auth=TOKEN`) returns all nodes → flags.
- Node path is often the app's look-up key (e.g. `Shroomishie`).

## Pitfalls
- Kali's `jadx` wrapper changes cwd — always pass absolute input/output paths.
- `strings` on resources.arsc adds `''` noise; use apktool-decoded strings.xml.
- CTFd (eqctf.com) needs register + create team before `/api/v1/challenges` works.
- HackMD image URLs 404 without a referer header.
- OCR of 9px URL text is unreliable — prefer the largest screenshot copy
  (HackMD uploads are often 2-4x the GitHub-hosted version).
