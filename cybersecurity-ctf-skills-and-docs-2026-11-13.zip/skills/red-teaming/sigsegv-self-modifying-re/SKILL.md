---
name: sigsegv-self-modifying-re
description: "Use for SIGSEGV-handler self-modifying binary reversing."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux]
metadata:
  hermes:
    tags: [ctf, reversing, anti-analysis, signal-handler, self-modifying, tea, obfuscation]
---

# SIGSEGV self-modifying obfuscation

Some RE challenges hide constants behind a SIGSEGV handler: the code dereferences an
invalid absolute address, faults, and the signal handler computes the real value and
resumes past the faulting instruction. This beats static xrefs (the constant is never
stored in .data) and is usually ASLR-independent (keyed on the faulting address = CR2,
not the RIP).

## Recognition
- A signal handler installed early (init_array -> sigaction), symbols like
  `segsegv_handler`, `resolve_sigaction`, `sm_crc32_*`.
- `movabs r64, <huge unmapped addr>` followed by `mov r64, [r64]` / `[r64+8]`.
- `get_module_base` / `get_elf_header` / `resolve_elf_sym_*` self-analysis helpers.
- `check_tracer` / ptrace checks (anti-debug) alongside.

## Reverse the handler
1. Identify the handler's ucontext offsets: on x86-64 glibc, `ucontext+0x90`=RAX,
   `+0xa8`=RIP, `+0xa0`=RSP, `+0xd8`=CR2 (faulting address). The handler writes the
   computed value to RAX and bumps RIP by the faulting instruction length.
2. The handler often gates branches on a CRC/checksum of CR2 (or RIP); map each
   distinct faulting address to its constant.
3. The constant is usually decrypted with a tiny cipher (TEA/XTEA) keyed on CR2
   (e.g. `key = CR2 * K1, CR2 * K2`). Replicate the exact arithmetic: watch for a
   MODIFIED initial `sum` (e.g. not `delta*rounds`) — don't assume stock TEA.
4. Reproduce in Python (uint32 arithmetic, mask every op with 0xffffffff).

## Pitfalls
- Ghidra's decompiler can LIE about in-place mutation when the real code mutates a
  stack COPY. Always cross-check the disassembly for where the result is read back
  (e.g. AES key passed from `rsp+0x10` while the XOR happens at `rsp`).
- Confirm the AES/stream cipher is truly standard (sbox/rsbox/Rcon, MixColumns,
  ShiftRows) before assuming you can reuse a crypto library — some challenges
  modify ShiftRows (the "potato"-style tweak).
- The obfuscated address often fails a `readelf -r` check (no R_X86_64_64 reloc),
  which is the tell that it must be faulted/patched at runtime.
