---
name: diff-stack-binary-reversing
description: "Use when a CTF has dev/prod binary pairs; diff them."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux]
metadata:
  hermes:
    tags: [reversing, ctf, diffing, dev-prod, stripped, crypto, chain]
---

# Diff-Stack Binary Reversing (dev vs prod)

Use when a challenge ships TWO versions of the same binary (e.g. `dev` and `prod`)
and the premise is "someone changed/removed something" (an intern removed weak crypto,
a dev fixed a bug, etc.). The flag lives in WHAT CHANGED — usually the crypto chain
kept its algorithm stack but swapped keys/alphabets, or a check was altered.

## Workflow
1. Recon both binaries in parallel:
   - `file`, `sha256sum`, `ls -la` — note stripped vs not-stripped (`nm` symbols!).
   - The unstripped one is the Rosetta Stone: `nm` gives function names (rc4Encrypt,
     customBase64, initializeSBox, ...) that document the whole chain.
   - `strings -n 5` both; diff the interesting strings (alphabets, keys, "Correct!").
2. Diff the data first — fastest signal:
   - `objcopy --dump-section .rodata=dev.rodata dev` (same for prod), then compare
     hexdumps. Look for: base64 vs base58 alphabets, key strings, blob sizes.
3. Map the chains:
   - Unstripped: decompile `main` — get the transform order + compare blob.
   - Stripped: find `main` via xref to "Enter Flag: " (search_byte_patterns →
     get_xrefs, or `objdump -d | grep` the RIP-relative lea), then create functions
     at prologue starts (`push %rbp` after alignment) and decompile each.
4. Identify each transform (patterns):
   - `'!' + ((c + n) % 0x5e)` over isprint = ROT47-variant (n != 47 is fine).
   - `out = base + ((key_c - base_key) + (in - base_in)) % 26` = Vigenere-style.
   - `(b1>>2)+0x20, (b2>>4|(b1&3)<<4)+0x20, ...` + backtick 0x60 padding = UUencode.
   - SBox 256-init + `s[i]+s[j] mod 256` swaps + xor = RC4 (key from KSA init).
   - divmod 0x3a (58) + alphabet + '1' zero-padding = base58 (Bitcoin-style).
5. Reconstruct the FULL chain for each binary, then diff the chains: same algorithm
   stack with different keys = the "needle" (the removal claim is usually FALSE).
6. Reverse the prod (target) chain: blob → invert each stage in reverse order
   (RC4 is symmetric; UUdecode; Vigenere decode; ROT inverse — watch for
   non-invertible mappings like 95→94 char spaces, try both candidates).
7. VERIFY: `printf '<flag>\n' | ./prod` must print "Correct!".

## Pitfalls
- Stripped binaries: Ghidra's auto-analysis may NOT create the code functions
  (only PLT stubs). Find starts via `objdump -d | grep -B1 'push %rbp'` then
  `create_function` at each.
- RIP-relative lea targets in objdump are exact — don't assume a string starts at a
  "nice" address; read the actual bytes (xxd) to confirm ("sus" can sit at 0x5043
  while a sibling reference points at 0x5047 = empty string — keys can be generated,
  not constant: `string key = ""; key += 'a' + (1<<i)` → "abdhp").
- Keys can be DERIVED: vigenere key = base64/base58("keymaterial"); RC4 key may be
  built at runtime by a builder function — decompile the KSA's key source.
- isprint/islower/isupper imports tell you which transforms do case/printable math.
- A decoy flag in the dev binary ("you_have_reached_the_end") is a hint, not the
  answer — prod is the target.

## Verification
- flag prints "Correct!" when piped into the binary.
- solver script reverses each stage; intermediate outputs should be printable
  (encoded text), final output matches flag format.
