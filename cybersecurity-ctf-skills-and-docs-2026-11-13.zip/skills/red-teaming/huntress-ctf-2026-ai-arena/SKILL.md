---
name: huntress-ctf-2026-ai-arena
description: "Use when playing Huntress CTF 2026 AI Arena on CourseStack."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux]
metadata:
  hermes:
    tags: [ctf, huntress, coursestack, game-master, api]
---

# Huntress CTF 2026: AI Arena (CourseStack) — play procedure

Event `92371a95-2ab9-46eb-8f6f-c676bceeed62`. Mechanics: CourseStack is the only
scoreboard. CourseStack lessons hold native questions; everything else is brokered
by the **Game Master** at `http://10.0.0.219/huntress-ctf-proxy` (no trailing
slash), which is not reachable from the public internet.

## 1. Authenticate without a password (Supabase cookies)

The session lives in non-HttpOnly chunked cookies on `ctf.huntress.com`:
`sb-auth-auth-token.0` / `.1`. If the player is logged in on their own Firefox,
read them from the profile — no password, no vault:

```python
import sqlite3
# flatpak path; native Firefox is ~/.mozilla/firefox/<profile>/
db = "~/.var/app/org.mozilla.firefox/config/mozilla/firefox/<profile>/cookies.sqlite"
con = sqlite3.connect(f"file:{db}?immutable=1", uri=True)
rows = con.execute("select host,name,value from moz_cookies "
                   "where host='ctf.huntress.com' and name like 'sb-auth-auth-token%'").fetchall()
cookie = "; ".join(f"{n}={v}" for h, n, v in rows)
```

Send as a `Cookie:` header to `https://ctf.huntress.com/api/...`. These rotate:
on a 401 re-read the profile instead of debugging.

## 2. Platform API map (cookie-authenticated)

| Purpose | Request |
|---|---|
| Event + curriculum | `GET /api/student/events/<event_id>` |
| All lessons + questions + artifact ids | `GET /api/student/events/<event_id>/take` |
| Download artifact | `GET /api/student/content/<playthrough_id>/files/<file_id>` |
| **Submit answer** | `POST /api/student/content/<playthrough_id>/lessons/<lesson_id>/submit-question` body `{"questionId":"<qid>","submission":"<value>"}` |
| VPN profile | `GET /api/student/courses/<playthrough_id>/vpn` |
| Homebase power | `POST /api/student/courses/<playthrough_id>/systems/<system_id>/power` body `{"power":"on"}` |
| Homebase web URL | `POST .../systems/<system_id>/connect` body `{"connectionIndex":0,"isNew":true}` -> `{"url":"https://<id>.proxy.coursestack.com/coursestack-auth#token=..."}` |
| Scoreboard | `GET /api/student/events/<event_id>/scoreboard` |

`GET /api/student/events/<id>/take` is the single best call: every chapter/lesson
dump, rendered markdown, `file` items with artifact ids, and every
`question-free-text` with `id`, `points`, `match_type`, `state`
(`unanswered`/`correct`) — use it to see exactly what is already solved.

## 3. Reaching the Game Master (the real bottleneck)

**The player VPN alone does not work.** The tunnel establishes and pushes
`10.0.0.0/16` + `10.1.0.0/16`, but every probe to `10.0.0.219`, `10.0.0.1`, or the
Homebase `10.1.69.112` times out with `rx_delta=0`; only the gateway `10.200.0.1`
answers (TCP RST). Rootless-podman recipe if you still want the tunnel:

```bash
podman run -d --name ctfvpn --network pasta --cap-add=NET_ADMIN \
  --security-opt label=disable -v /dev/net/tun:/dev/net/tun:rw \
  -v $PWD:/ctf:rw --entrypoint sleep python:3.12-slim-bookworm infinity
podman exec ctfvpn sh -c 'apt-get update -qq && apt-get install -y -qq openvpn iproute2'
podman exec -d ctfvpn openvpn --config /ctf/huntress-ctf-2026-ai-arena.ovpn --log /ctf/openvpn.log
```

`--device /dev/net/tun` fails (device cgroup); the bind mount plus
`--security-opt label=disable` (SELinux) works. Start openvpn with `podman exec -d`;
kill with `pkill -x openvpn` (`pkill -f` kills its own shell; `procps` absent by
default).

**Do the Game Master work inside the AI Homebase VM.** Power it on, take the
`connect` URL, and drive the VM's T3 Code UI in the browser (public HTTPS proxy,
so no VPN needed from your host):

1. `browser_navigate` to the connect URL — it stores the `token` cookie and reloads.
2. Wait for the SPA, then post into the **agent chat** (readable text, unlike the
   canvas-rendered terminal).

```js
// composer is the single [contenteditable="true"] on the page
const ce = document.querySelector('[contenteditable="true"]');
ce.focus();
document.execCommand('insertText', false, msg);
[...document.querySelectorAll('button')].find(b => /send message/i.test(b.getAttribute('aria-label')))?.click();
// read the answer back with document.body.innerText
```

Prompt that works (the Homebase agent already has AGENTS.md):
> List the challenges available right now via the Game Master
> (`curl -fsS 'http://10.0.0.219/huntress-ctf-proxy?op=list'`), start
> `<challenge-id>`, show every instruction and answer id, then submit
> `{"challenge":"<id>","answers":{"<answer_id>":"<value>"}}` and paste the raw
> JSON response verbatim.

## 4. Solve procedure that works

- **Read the Rules** needs no Game Master: the flag is an HTML comment on
  `/rules` injected client-side, so `curl` of the raw HTML does **not** contain
  it. Load it in a real browser and grep `document.documentElement.outerHTML` for
  `<!-- flag{...} -->`; submit the whole `flag{...}` string.
- **Welcome Robots** (orientation): the Game Master `start` response hands you the
  answer directly with `answer_id` = `flag`, and `op=artifact` returns
  `invalid_delivery` (no file). Submit that value back to the Game Master; it
  replies `{"result":"CORRECT",...,"flag":"<completion code>"}`; submit the
  returned flag to the lesson's CourseStack question (`match_type` is `dynamic`).
- Compounding challenges (A Little Based, You Must Be This Hash to Ride, Power
  Play, Exported Trust, ELF Aware) expose three questions each:
  `*_investigation` (Single Solve), `*_sprint` (Time Trial, server-enforced
  deadline), `*_mastery` (bundle, one shared timer). Their Single Solve artifacts
  download straight from the lesson; the byte-level answer must still be
  validated through the Game Master.
- **CourseStack questions with `match_type: "dynamic"` are auto-completed by the
  Game Master.** Once it returns `{"result":"CORRECT","flag":"<32-hex>"}` the
  lesson question flips to `state: "correct"` on its own — do NOT try to
  `submit-question` those (only `exact` ones like `read_the_rules` need a manual
  POST). Verify by re-GETting `/api/student/events/<id>/take`, not by the agent's
  say-so.
- Game Master payload shape: each mode returns its `questions[].id` up front
  (`message` for single-solve/time-trial; `set1.message`..`setN.message` for
  Mastery), an `artifact` filename, and an `answer_format` (`kind: "pattern"`,
  often `normalization: "trim"`, submit the slug only). Mastery artifacts can be
  a **ZIP of N individually base64-encoded blobs** — one blob per set, decode each
  separately. Time Trial/Mastery need one script per run that does
  start+artifact+decode+submit in a single shot to beat the server deadline.
- The Homebase agent sometimes returns one `"incorrect"` before its `"CORRECT"`;
  read the raw JSON blocks rather than the first result you see.
- **Lesson artifacts are a static reference copy — do not hash those.** The Game
  Master assigns a per-attempt artifact (e.g. `metadata-day-01-evidence.zip ->
  evidence-note.txt`) and the answers must be computed from *those* bytes. Metadata
  Forensics answers are typically digests: SHA-1 as exact 40-char lowercase hex and/or
  SHA-256 as exact 64-char hex, `case_insensitive`, no prefix or extra text. Hash the
  exact extracted bytes (no re-save, no added newline) and script the whole
  fetch+hash+submit in one shot to beat the 1s/3s Time Trial and Mastery deadlines.
- Artifact links come back as a root-relative
  `/api/huntress/game-master/download/<capability>` path — hand those to the browser,
  not to your host's curl.
- **Send the Homebase agent ONE challenge per message.** A single prompt asking for
  three challenges x three modes died with `stream disconnected before completion:
  The server had an error while processing your request` and the thread flipped to
  `Failed` with nothing scored. One challenge per prompt (still asking for all three
  modes) works: Power Play, Exported Trust and ELF Aware each finished in ~2-5 minutes.
  Retrying inside an already-`Failed` thread is fine — the thread state does not block
  the next run.
- **Poll `GET /api/student/events/<id>/take` to track progress, not the browser.**
  `state` flips `unanswered` -> `correct` per mode as the Game Master lands each one
  (typical order: investigation, then sprint, then mastery). Polling also survives
  camofox tabs dying with `410 Gone`, which they do constantly on the proxy domain.
- Hermes' own browser tab can get stuck on a dead tab id (every call returns
  `410 ... /tabs`). Deleting the session with
  `DELETE http://127.0.0.1:9377/sessions/<userId>` clears it, but Hermes still caches a
  stale id; the reliable escape is the **camofox MCP tools** (`camofox_create_tab`,
  `camofox_evaluate`, `camofox_navigate`), which manage their own tabs. If the app shows
  "T3 Code could not load", set the cookie yourself on the proxy origin and reload:
  `document.cookie='token='+encodeURIComponent('<token>')+'; path=/'; location.reload();`
- Day 01 shape for reference: Read the Rules + Welcome Robots are 10 pts each; the other
  five challenges are 2 + 3 + 5 = 10 pts each (investigation/sprint/mastery) = 70 pts total.
  Lanes: Warmups (base64), Metadata Forensics (SHA-1 + SHA-256 of the assigned file),
  Script Analysis (Power Play = 3 PS1 specimens, 15 answer fields), Mobile Android
  (Exported Trust = APK, AndroidManifest + assets/huntress_puzzle.json), Binary
  (ELF Aware = slot-0.elf).
  `document.body.innerText` only ever shows the tail plus whatever is mounted. If you
  need flags as evidence, make the agent print them in its final message, or read the
  thread immediately instead of coming back later — re-reading a long thread yields
  empty results (`Rendering`/`Reconnecting` placeholders).

## 5. Automation (daily cron runner)

Job `dc915274f1ef` ("Huntress CTF 2026 daily runner") runs `5 21 * * *` — 21:05 local
(+08) = 09:05 AM Eastern, just after the daily credit refill / challenge drop. It loads
this skill, uses `continuity: true`, and works left to right: re-read cookies → list every
question whose `state != "correct"` → probe the VPN for the Game Master (free path, use it
if it ever answers) → otherwise power on the Homebase, work **one challenge per prompt**,
verify each flip to `correct` on the course API, then power the VM off unconditionally.
If nothing is open or the event ended it exits without starting the VM.

**Driving the Homebase without MCP tools.** A cron session may not have the camofox MCP
tools registered, so use the camofox REST API on 127.0.0.1:9377 with plain curl (tested):

```bash
TAB=$(curl -sS -X POST http://127.0.0.1:9377/tabs -H 'Content-Type: application/json' \
  -d '{"userId":"cron-huntress","sessionKey":"daily","url":"<connect url>"}' \
  | python3 -c "import sys,json;print(json.load(sys.stdin)['tabId'])")
curl -sS -X POST "http://127.0.0.1:9377/tabs/$TAB/evaluate" -H 'Content-Type: application/json' \
  -d '{"userId":"cron-huntress","expression":"<js>"}'      # -> {"ok":true,"result":...}
curl -sS "http://127.0.0.1:9377/tabs/$TAB/snapshot?userId=cron-huntress"
curl -sS -X DELETE "http://127.0.0.1:9377/tabs/$TAB?userId=cron-huntress"
```

Use a dedicated `userId` (never `hermes_*`) so the automation cannot disturb the
interactive browser session. Set the proxy cookie by hand, then reload — the T3 UI shows
"T3 Code could not load" until that cookie exists.

Credit accounting: there is **no** per-account balance endpoint (`/me`, `/credits` → 404).
The only figures exposed are the event's `included_credits` and the playthrough's
`included_runtime_gb_seconds`; real spend is only observable via the power-on response
(`{"error":"bad_request","message":"You are out of credits"}`).

## 5b. Working one challenge (proven loop, Days 01-02 all cleared this way)

Per challenge, ~3-15 min of agent time. Send **one challenge per prompt**; a prompt asking for
several challenges kills the model stream and scores nothing.

1. Statically analyse the lesson artifact locally FIRST (free, no VM) and put the findings in the
   prompt - it stops the Homebase agent re-deriving basics and shortens the timed runs.
2. Pack the prompt with: challenge name, lane, "all three modes", the local findings, and the
   reminder to work from the exact assigned bytes and paste raw JSON.
3. Poll `GET /api/student/events/<id>/take` every 30s; typical per-mode latency 30s-5min
   (`investigation` first, then `sprint`, then `mastery`). `mastery` can take ~15 min.
4. Power the VM off the moment the challenge is done.

### Prompt delivery (this bit silently fails if rushed)
`document.execCommand('insertText',...)` then **wait 1.5-2s** before clicking the button whose
aria-label matches `/send message/i`. Clicking in the same tick no-ops - React has not registered
the text yet, the message stays in the composer, and nothing runs.

When the agent asks a question, the UI shows "User input requested" with options plus
"Type your own answer". The main composer IS the answer field: insertText, wait, then click the
`Submit` button. Answer with concrete evidence, not just a pick.

### Encrypted archives (the Day-01 -> Day-02 carry-forward)
Assigned zips are **WinZip AES** (`method 99`, AE-3), and the password carries forward between
days - Day 02 reused Day 01's `infected` for both Host With the Most and Mangled.
- `python3 -m zipfile` / `unzip` CANNOT read WinZip AES. Their failure reads as "password
  required", which looks exactly like a wrong password - a false negative. `7z x -pinfected` works.
- If the password is unknown, ask the Homebase agent to look back at its OWN earlier thread in the
  workspace (threads persist on the VM) - it records how the previous day's archive was opened.
- ZIP password verification alone is only 16 bits, so validate against the AES auth tag.

### Per-field mastery validation
Mastery submissions can be partially accepted per field (e.g. 30/34) and report `remaining: N`.
When specific fields keep being rejected while others pass, isolate them and vary the spelling
(symbol fields: mangled vs demangled, leading underscore, MSVC decoration vs Itanium ABI).

### Browser hygiene
camofox tabs are reclaimed mid-run (repeated `404 Tab not found`). The VM-side agent run is
unaffected - just create a fresh tab at the connect URL, set the token cookie, reload, and open the
thread from the sidebar. Re-check state from the course API, never from a dead tab.

## 6. Timed modes assign a FRESH pack (and the GM is reachable without the VM)

**Two facts that invalidate the "reuse the single-solve answer map" plan:**

1. **`op=artifact` for a timed mode hands back newly generated bytes.** `time_trial`
   returned a 20,567-byte pack (sha256 `1319e5dd…`) where single-solve got 21,255 bytes
   (`ce1a3fb0…`); a later attempt got a third pack again. Same 21 filenames, same WinZip
   AES password (`infected`), but **every campaign id, url, path, adapter and control
   construct is re-rolled**. Never carry single-solve values into the timed modes — and
   note a blitz that probes single-solve labels against a fresh attempt can never converge.
2. **The GM is reachable straight from the host with a paired bearer** — no VPN and no
   Homebase VM:
   ```
   GM = https://2026.huntress.ctf.games/     # Authorization: Bearer <token>
   token = ~/.huntress/gm_token              # obtained by POST ?op=pair via the proxy once
   GET  ?op=status&challenge=<id>/<mode>     # mode suffix: '' | /time_trial | /mastery
   GET  ?op=artifact&challenge=<id>/<mode>   # assigned bytes for THIS attempt
   POST {"op":"start"|"retry"|"submit", "challenge":"<id>/<mode>", "answers": {...}}
   ```
   Challenge id for Expansion Pack: `script-analysis-day-03-batch-expansion`.
   `op=status` reports `result` = `expired` / `start_required` / `CORRECT`. `/v1`-style
   `.../time_trial` and `.../mastery` are **path suffixes on the challenge id**, not separate
   challenges.

**The GM is a per-field oracle.** Timed modes grade field-by-field and report
`remaining`; accepted fields persist across `op=retry`, and `op=retry` re-opens a fresh
~6s window on the same material. So an unknown label can be discovered by probing: fire a
candidate, keep it if `remaining` drops. Submit **one field per window** — 3+ submissions
inside one window come back `incorrect`/`expired` and mislead you into discarding correct
values (this cost real time). A field that rejects a value in several *solo* windows is
 genuinely wrong.

`HTTP 200 {"result":"incorrect"}` carries no `remaining`; only `accepted` does, as
`{"result":"accepted","remaining":N}`.

**Expansion Pack auto-solver** (written and working; ~150 of 159 fields derived
mechanically, the rest are label guesses):
```
~/.huntress/expansion_solver.py   # pack dir -> {answer_id: [candidate, ...]}
~/.huntress/js_recover.js         # node harness: executes a .js recover_*() and prints JSON
~/.huntress/gm_probe.py           # windowed prober against the oracle
```
Decode rules that matter:
- Batch `rem HUNTRESS-CODEC:<c0>|<c1>` + `rem HUNTRESS-MATERIAL:<m>` chains vary per pack
  and include `add_7` / `sub_7` / `rotate_left` / `reverse_xor`, so **brute-force the chain**
  (b64/hex/decimal/reversed_text first, then reverse/xor5a/xor33/rot±1/addN/subN) and accept
  the first result starting with `v=1|steps=`. Do not hardcode per-file transforms.
- The 4 inspect fragments concatenate **in index order with overlapping boundaries**
  (`…return_config` + `uration|adapter=…`); joining h0..h3 reproduces the same plan as the
  decoded material, so either can be used to cross-check.
- **JScript must be executed, not hand-decoded** — each file uses a different obfuscation
  (hex triplets ± xor, decimal arrays, base64 ± key, chained xor). Running the file's own
  `recover_*()` under `node` (with `ActiveXObject`/`WScript` stubbed) recovers every
  descriptor reliably.
- PowerShell descriptors are real base64 JSON; the `'eyJhIj...MifQ=='` you see in a terminal
  dump is **display redaction, not truncation** — read the bytes in Python and b64-decode
  them. Keys: resource → b=url, c=wallet, h=mutex; collection → b=url, c[0]=first filename,
  f=user-agent; impact → b=extension, c=note, d=url.
- Known-good `exact_text` labels so far: `goto_dispatch`, `call_subroutine`,
  `errorlevel_guard` (batch control); `percent` / `delayed` / `call_double` / `for_indirect`
  (expansion — literal words from the question text); graph values are literal in the plan
  (`linear`, `single`, `fan_out`, `diamond`, `same_language`, `cross_language`,
  `fallback_retry`); `none` is accepted for a benign specimen's ATT&CK id.
- **Unresolved:** the 9 `batch-*-control` labels are an open-ended verb_object vocabulary
  (a `for %%G … do call set` indirection, `echo X | findstr Y >nul`, `ver >nul && rem`,
  `set "x=…"& rem`, `if defined …`, `goto :LABEL`, `call :LABEL`). Guessing has a low hit
  rate; several *cleanly decoded* values (e.g. `batch-chain-adapter = cscript.exe`) are also
  rejected outright, so treat `exact_text` labels as untrusted until the oracle confirms them.

## Pitfalls (all observed live)

- Flags are dynamic per team (`[0-9a-f]{32}`). Never use another team's flag,
  artifact, or answer id — cross-identity values never validate.
- `browser_vault_save_login` does not work with the camofox provider
  ("Open the site's login page first"). Harvest cookies from the player's own
  browser instead of fighting it.
- `camofox_import_cookies` requires `CAMOFOX_API_KEY`, but the loopback REST route
  `POST http://127.0.0.1:9377/sessions/<userId>/cookies` accepts Playwright cookie
  objects without it when `NODE_ENV != production`. Firefox `expiry` values are
  ms-scale and Playwright rejects them — send `expires: -1` or omit it. Hermes'
  userId looks like `hermes_<hash>`; find it in `~/.camofox/profiles/*/meta.json`.
- `.../systems/<id>/connect` returns 400 "Old app version detected" unless the
  body is the full `{"connectionIndex":0,"isNew":true}`.
- The T3 terminal drawer is canvas (ghostty-web) — output is not in the DOM. Use
  the agent chat; `browser_vision` on the drawer frequently times out.
- Browser tabs on the proxy expire (~30 min) and `browser_console` then returns
  `410 Gone`/`400 ... /tabs`: re-`browser_navigate` and continue. A fresh
  navigation occasionally refuses evaluate once — just retry.
- The Homebase VM bills credits (~4/hr). Power it off when finished.
