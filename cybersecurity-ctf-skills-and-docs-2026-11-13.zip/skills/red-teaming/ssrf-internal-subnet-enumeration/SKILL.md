---
name: ssrf-internal-subnet-enumeration
"description": "Use when SSRF is unfiltered and must find internal services."
version: 1.0.0
license: MIT
metadata:
  hermes:
    tags: [ctf, web, ssrf, internal-network, discovery]
---

# SSRF: find hidden internal services on the app's own subnet

When a URL-fetching endpoint reflects 200 bodies, treat it as a network-position
oracle and enumerate the docker/compose subnet the app runs on - do NOT stop at
127.0.0.1 or the cloud-metadata IP.

## Host-existence oracle (connect timing)
- Probe each candidate IP on a surely-closed port (e.g. :1) through the SSRF.
- LIVE host: connection refused quickly (app answers in <~1-2s).
- DEAD IP on the same /24: ARP/connect timeout (app answers only after its own
  requests timeout, ~3.5s+; tune the client timeout below the app's).
- Then port-scan only the live hosts (closed ports on live hosts refuse fast,
  so scans are quick). Run such sweeps single/low-concurrency - the target app
  is often near-serial and large parallel scans thrash it.
- Also check: app container IP (self-fetch often allowed -> hidden loopback
  routes), gateway, and every fast-responding host on the /24.

## After finding a service
- If it runs a custom file server with directory listing ("Index of ..."): walk
  EVERY dir, read EVERY file - configs, logs, manifests, and temp/ dirs.
- Read /metrics, /health and similar telemetry endpoints: they leak internal
  paths (backup dirs, log locations, artefact names) that lead to the payload.
- Stale QA/backup artefacts ("remove after sign-off", cleanup disabled) are the
  classic hiding spot for secrets.
- Response pages distinguish: empty-200 renders a bare form page, non-2xx and
  network errors render "Unable to retrieve resource.", some malformed URLs
  render a decoy "Blocked: ... restricted list." message - treat message text
  as data, not truth.

## Pitfalls
- Filters that look real may be decoys or partial: test loopback/RFC1918/
  link-local directly before building bypasses (0x7f000001, [::ffff:127.0.0.1],
  nip.io, DNS rebinding) - many CTF instances have NO effective filter.
- Port scans through a near-serial app are slow: cap workers (~8-20), use short
  client timeouts, and prefer targeted port sets over full 65535 sweeps.
