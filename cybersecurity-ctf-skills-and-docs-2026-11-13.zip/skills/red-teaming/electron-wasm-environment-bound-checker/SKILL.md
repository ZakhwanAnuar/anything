---
name: electron-wasm-environment-bound-checker
description: "Use when Electron WASM checks use browser fingerprints."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux]
metadata:
  hermes:
    tags: [ctf, reversing, electron, wasm, environment-fingerprint, rc4]
---

# Electron WASM Environment-Bound Checker

Use for CTF Electron applications where a WebAssembly verifier behaves differently outside the packaged runtime, dynamically evaluates browser APIs, or decrypts its expected value from `Function.prototype.toString()` fingerprints.

## Workflow

1. Extract the package:
   - AppImage: copy it, make the copy executable, run `--appimage-extract`.
   - Electron archive: `npx --yes @electron/asar extract resources/app.asar app/`.
   - NSIS EXE: `7z x installer.exe`; unpack its embedded `app-64.7z` and compare `app.asar` hashes across platforms.
2. Locate embedded WASM in HTML/JS. A decimal `Uint8Array` beginning `31,139,8` is gzip data. Parse the integers and run `gzip.decompress()`.
3. Produce both views:
   - `wasm2wat code.wasm -o code.wat`
   - `wasm-decompile code.wasm -o code.dcmp`
   - `wasm-objdump -x code.wasm`
4. Trace the exported checker into its internal function. Identify input length checks, target-copy addresses, PRNG operations, dynamically generated key material, and the final transform/compare.
5. Do not trust a system Chromium reproduction when startup fingerprints browser-native functions. Different Chromium/Electron versions have different native `toString()` lengths and therefore derive different target bytes.
6. Instrument the **bundled Electron runtime**:
   - Unpack `app.asar` to a separate runtime app.
   - Hook `WebAssembly.instantiate` before the module loads and save the imported `env.memory` plus instantiated module on `window`.
   - Preserve the exact script index used by any dynamic key derivation. If the checker hashes `document.querySelectorAll('script')[1].textContent`, modify script 0 or append a later script; never alter script 1.
   - If CSP hashes block instrumentation, move the original hash token to a harmless `default-src` position while allowing inline instrumentation with a separate `script-src`. Preserve token ordering when code extracts it with `content.split(' ')[N]`.
   - Replace the main process entry with a minimal `BrowserWindow` harness that calls `webContents.executeJavaScript()`, returns only JSON-serializable strings, writes the capture to disk, and exits.
7. Capture the exact post-initialization comparison target, environment accumulator, dynamic key, and any evaluated seed such as `(typeof global).length`.
8. Reimplement the transform carefully. For custom i32 PRNGs, preserve modulo-2^32 wraparound and distinguish `i32.shr_u` from `i32.shr_s` by checking WAT, not decompiler pseudocode.
9. Recover the candidate and verify it by calling the original exported checker inside the bundled runtime. A direct `check_flag`/`window.checkFlag` success is the completion criterion.

## Minimal WASM hook

```js
const orig = WebAssembly.instantiate;
WebAssembly.instantiate = async function (...args) {
  const result = await orig.apply(this, args);
  window.__wasmResult = result;
  window.__wasmMemory = args[1]?.env?.memory;
  return result;
};
```

## Key pitfalls

- `debugger` in a loop can hang CDP-driven automation. Avoid enabling the Debugger domain, or use `Debugger.setSkipAllPauses` before navigation.
- A successful headless Chromium solve may still be wrong for the bundled Electron version because native-function source text changes by release.
- Modifying the script used as dynamic key material silently changes the key.
- Electron `executeJavaScript()` rejects non-cloneable objects such as WebAssembly instances or typed-array-backed structures. Convert captures to JSON in the renderer.
- Browser sandboxing changes `typeof global`; reproduce the original `BrowserWindow.webPreferences`.
- Decompiler `>>` may hide whether WASM uses `i32.shr_u`; consult WAT.
