---
name: r2r-dotnet-reversing
description: "Use when reversing ReadyToRun binaries with neutered IL."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux]
metadata:
  hermes:
    tags: [reversing, dotnet, readytorun, r2r, crossgen2, malware, ctf, native]
---

# ReadyToRun (R2R) .NET Reversing

Use when a .NET assembly is R2R-compiled (Crossgen2 AOT): the IL may be present but
neutered (nops/stubs) while the REAL logic runs from native x64 code in the image.
Classic CTF twist ("we need to go native") and malware-evasion technique (R2R stomping).

## Detection
- `strings <dll>` shows `Crossgen2 <ver>` (e.g. "Crossgen2 6.0.3324.36610") and a PDB
  path under `obj\Release\netX.Y\win-x64\`.
- PE has TWO `.text` sections: first = R2R native code, second = IL + metadata.
- COR header `ManagedNativeHeader` field is non-zero and points to the R2R header
  (magic 0x525452 = "RTR").

## Key facts (from dotnet/runtime src/coreclr/inc/readytorun.h)

### R2R header layout — GET THIS RIGHT
```
struct READYTORUN_HEADER {
  DWORD Signature;      // 0x525452
  USHORT MajorVersion;  // 5
  USHORT MinorVersion;  // 4
  DWORD Flags;          // READYTORUN_FLAG_* (0x8 = NONSHARED_PINVOKE_STUBS, 0x10 = EMBEDDED_MSIL, 0x20 = COMPONENT)
  DWORD NumberOfSections;
  READYTORUN_SECTION Sections[];   // starts at header + 0x10
};
struct READYTORUN_SECTION {
  ReadyToRunSectionType Type;  // DWORD
  IMAGE_DATA_DIRECTORY Section; // DWORD RVA, DWORD Size   <-- (Type, RVA, Size), NOT (Type,Size,Offset)!
};
```
Pitfall: sections are (Type, RVA, Size) — the old layout (Type, Size, RelativeOffset)
overlaps garbage. Section types: 100 CompilerIdentifier, 101 ImportSections,
102 RuntimeFunctions, 103 MethodDefEntryPoints, 104 ExceptionInfo, 105 DebugInfo,
106 DelayLoadMethodCallThunks, 108 AvailableTypes, 109 InstanceMethodEntryPoints,
112 ManifestMetadata, 114 InliningInfo2, 118 ManifestAssemblyMvids.

### RuntimeFunctions = native code map (fastest path)
Section 102 is an array of RUNTIME_FUNCTION {BeginAddress, EndAddress, UnwindData}
(12 bytes each). Each entry = one native function. The BIG one is usually Main.

### MethodDefEntryPoints = NativeArray (trie) — painful
Section 103 is a NativeArray: header varuint (nElements = val>>2, indexSize = val&3),
per-block offset table (1/2/4-byte entries per 16 methods), then a binary trie.
Leaf decode: `id = DecodeUnsigned(offset); if (id&1) { if (id&2) skip fixup; id>>=2 } else id>>=1;`
→ id = index into RuntimeFunctions. You rarely need it: RuntimeFunctions + size heuristic
find Main.

### Import sections
Section 101 = array of READYTORUN_IMPORT_SECTION {Section{RVA,Size}, Flags(2), Type(1),
EntrySize(1), Signatures RVA, AuxData RVA}. Cells are ZERO in the file (fixed up at load).
The "Signatures" blob is NOT a name table — it's compressed method-signature blobs
(needs metadata to resolve). Don't hand-decode; use Ghidra + logic analysis instead.

## Workflow
1. Recon: `file`, `strings`, `monodis GetReadyToRun.dll` (types + methods + IL).
   - If Main's IL is all `nop`s after loading a string / P/Invoke list → IL neutered.
   - P/Invoke list reveals the real API surface (CreateProcessW, VirtualAllocEx,
     WriteProcessMemory, SystemFunction033, ...).
2. Parse R2R sections (r2r_parse.py pattern) → get RuntimeFunctions.
3. Load into Ghidra (headless MCP):
   - `POST http://127.0.0.1:8089/load_program` body `{"file": "/abs/path.dll"}` (import_file
     MCP tool needs GUI — use the REST API instead).
   - Decompile native Main at ImageBase + BeginAddress (ImageBase usually 0x180000000).
4. Identify calls through import cells (*pcRam...). Map by ARG PATTERNS, not names:
   - 1 string arg repeatedly = Console.WriteLine
   - (obj, url-string) returning string/byte[] = WebClient download
   - 10-arg call with CREATE_SUSPENDED (0x8000000) = CreateProcessW
   - (hProcess, 0, size, 0x3000, 0x40) = VirtualAllocEx
   - (hProcess, addr, buf, size, &written) = WriteProcessMemory
   - (CRYPTO_BUFFER&, CRYPTO_BUFFER&) = SystemFunction033 (decrypt)
5. Embedded blobs: an ASCII SHA256 in the native section often verifies the KEY
   (sha256(key) == embedded hash). CRYPTO_BUFFER = {DWORD Length, DWORD MaximumLength,
   PVOID Buffer} — 16 bytes.
6. Decrypt the payload. SystemFunction033/RtlDecryptMemory with an 8-byte key = RC4
   (pycryptodome `ARC4.new(key).decrypt(data)`). 16-byte keys = AES-class. Data length
   NOT a multiple of 16 → stream cipher (RC4), not block.
7. Decrypted payload: often msfvenom-style x86 shellcode → `ndisasm -b 32`. Strings
   inside give the flag/placeholder; the C2 endpoint comes from the connect API args
   (InternetConnectA(hInternet, "IP", port, 0, 0, 3=HTTP, 0, 0) — port is host-order).

## Pitfalls
- `monodis` has NO `--il` flag — plain `monodis file.dll` dumps full IL incl. bodies.
- R2R images have no standard import directory (R2R import sections instead) → Ghidra
  won't auto-name imports; name cells manually from call patterns.
- Import cell RVAs sit in .data (e.g. 0x5078+) and hold 0 in the file.
- A `push 0x1388` in shellcode is often Sleep(5000) in a retry loop — not the port.
- `dotnet tool install --global ilspycmd/R2RDump` may fail on old SDKs ("You mistyped
  the name of the tool") — the python parser + Ghidra path needs no extra installs.

## Verification
- sha256(key) == embedded hash string (case-insensitive compare).
- Decrypted payload passes `file`/entropy check (shellcode = ~40-60% printable, has
  call-pop prologue fc e8 .. .. .. .. 60 89 e5).
- Flag format string appears verbatim inside decrypted payload.
