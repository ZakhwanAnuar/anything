#!/usr/bin/env python3
"""Parse ReadyToRun header, sections, runtime functions, and method entrypoints.

Usage: python3 r2r_parse.py <r2r-dll>
Outputs: R2R section table (correct READYTORUN_SECTION layout: Type, RVA, Size),
RuntimeFunctions (native function ranges — the big one is usually Main),
and a best-effort decode of the MethodDefEntryPoints NativeArray.

R2R header layout (dotnet/runtime src/coreclr/inc/readytorun.h):
  READYTORUN_HEADER { DWORD Signature(0x525452); USHORT Major; USHORT Minor;
                      DWORD Flags; DWORD NumberOfSections;
                      READYTORUN_SECTION Sections[]; }  // sections at +0x10
  READYTORUN_SECTION { DWORD Type; DWORD RVA; DWORD Size; }  // <-- (Type, RVA, Size)!
"""
import struct, sys

def parse_pe(path):
    d = open(path, 'rb').read()
    e_lfanew = struct.unpack_from('<I', d, 0x3c)[0]
    nsec = struct.unpack_from('<H', d, e_lfanew + 6)[0]
    opt_sz = struct.unpack_from('<H', d, e_lfanew + 20)[0]
    sec_tbl = e_lfanew + 24 + opt_sz
    secs = []
    for i in range(nsec):
        base = sec_tbl + i * 40
        name = d[base:base+8].rstrip(b'\x00').decode(errors='replace')
        vsz, va, rsz, roff = struct.unpack_from('<IIII', d, base + 8)
        secs.append((name, va, vsz, roff, rsz))
    def rva_to_off(rva):
        for name, va, vsz, roff, rsz in secs:
            if va <= rva < va + max(vsz, rsz):
                return roff + (rva - va)
        return None
    return d, rva_to_off, secs

def read_varuint(d, off):
    b = d[off]
    if b & 0x80 == 0:
        return b, off + 1
    if b & 0xC0 == 0x80:
        return ((b & 0x3F) << 8) | d[off+1], off + 2
    if b & 0xE0 == 0xC0:
        return ((b & 0x1F) << 24) | (d[off+1] << 16) | (d[off+2] << 8) | d[off+3], off + 4
    raise ValueError(f'bad varuint at {off:#x}: {b:#x}')

def main(path):
    d, rva_to_off, secs = parse_pe(path)
    print('SECTIONS:', [(n, hex(va), hex(vsz)) for n, va, vsz, _, _ in secs])

    e_lfanew = struct.unpack_from('<I', d, 0x3c)[0]
    dd_base = e_lfanew + 24 + 112
    cor_rva = struct.unpack_from('<I', d, dd_base + 14*8)[0]
    cor_off = rva_to_off(cor_rva)
    mnh_rva, mnh_sz = struct.unpack_from('<II', d, cor_off + 0x40)  # ManagedNativeHeader
    print(f'ManagedNativeHeader rva={mnh_rva:#x} sz={mnh_sz:#x}')

    r2r_off = rva_to_off(mnh_rva)
    magic, major, minor = struct.unpack_from('<IHH', d, r2r_off)
    flags, nsec_r2r = struct.unpack_from('<II', d, r2r_off + 8)
    print(f'R2R header: magic={magic:#x} ver={major}.{minor} flags={flags:#x} sections={nsec_r2r}')
    print(f'  flags: NONSHARED_PINVOKE={bool(flags&8)} EMBEDDED_MSIL={bool(flags&0x10)} COMPONENT={bool(flags&0x20)}')

    sec_base = r2r_off + 16
    types = {100:'CompilerIdentifier',101:'ImportSections',102:'RuntimeFunctions',
             103:'MethodDefEntryPoints',104:'ExceptionInfo',105:'DebugInfo',
             106:'DelayLoadMethodCallThunks',108:'AvailableTypes',109:'InstanceMethodEntryPoints',
             110:'InliningInfo',111:'ProfileDataInfo',112:'ManifestMetadata',113:'AttributePresence',
             114:'InliningInfo2',115:'ComponentAssemblies',116:'OwnerCompositeExecutable',
             117:'PgoInstrumentationData',118:'ManifestAssemblyMvids'}
    sections = {}
    for i in range(nsec_r2r):
        typ, rva, sz = struct.unpack_from('<III', d, sec_base + i*12)
        tname = types.get(typ, f'?{typ}')
        sections[typ] = (rva, sz)
        print(f'  [{i}] {tname:26s} type={typ} rva={rva:#x} size={sz:#x}')

    # RuntimeFunctions: array of RUNTIME_FUNCTION {BeginAddress, EndAddress, UnwindData}
    if 102 in sections:
        rva, sz = sections[102]
        off = rva_to_off(rva)
        n = sz // 12
        print(f'\nRUNTIME FUNCTIONS ({n}):')
        for i in range(n):
            b, e, u = struct.unpack_from('<III', d, off + i*12)
            print(f'  fn[{i:2d}] start={b:#08x} end={e:#08x} unwind={u:#08x} size={e-b:#x}')

if __name__ == '__main__':
    main(sys.argv[1])
