---
name: segment-budget-overflow-fnptr-overwrite
description: "Use when a parser reads a segment, then checks the budget."
version: 1.0.0
author: kubesame
license: MIT
platforms: [linux]
metadata:
  hermes:
    tags: [ctf, pwn, overflow, budget-check, global-array, function-pointer, libc-leak, bss]
---

# Read-then-check segment overflow -> overwrite adjacent global function pointers

Use when a raw-byte protocol reads variable-length "segments" (len byte + payload) into a fixed buffer and validates the segment length only AFTER the read (budget/remaining check misplaced), or generally when data lands in a global array of structs and an oversized single segment can run forward into the NEXT struct's fields.

## Pattern (SunCTF "Imagine Using Fable" codec)
- Non-PIE EXEC (fixed 0x40xxxx addresses), NX, canary present but irrelevant (all writes hit .bss, no stack).
- Protocol is RAW BYTES (read(0,...) exact-length), no prompts or line parsing: commands are b"D"+i+decl+..., b"P"+i, b"R"+i, b"L"+i+n, b"Q".
- Global array of N fixed-size doc structs in .bss: fn_ptr@+0 (initialized to a default render fn), len@+8, count@+0xc (dword, set by draw/setlen), data@+0x10 (40 B).
- Command draw(i, decl, segs): remaining=decl (validated <= data size), then per segment: read 1-byte len n, read n bytes into data+off, off+=n, ONLY THEN if n>=remaining stop else remaining-=n. A single n=255 first segment (decl>=1) overflows data by up to 215 B forward into following structs. Loop only continues while n<remaining so you CANNOT chain segments past the budget; one big first segment is the whole primitive (max 255 B).
- R render[i] does `call doc[i].fn` with rdi = doc[i].data -> overwrite a later doc's fn_ptr to any fixed/libc address and it gets called with a pointer to attacker-controlled bytes.
- system() via real call site: alignment is a genuine `call`, so no ret-gadget alignment dance.

## Exploit flow (verified end-to-end, glibc 2.35)
1. Compute offsets from doc[0].data: doc[1].fn = data0+0x28 (40 B in), doc[1].count = data0+0x34, doc[1].data = data0+0x38.
2. libc leak without an info-leak op: dlsym(0,"printf") result stored in .bss right after the array (dead store, never called) = libc+printf_off. Overwrite a doc's count dword via the overflow, then P preview[i] write()s count bytes from doc[i].data -> OOB .bss read reaches the parked libc pointer. Read blob offset = (target_addr - doc[i].data).
3. printf_off in glibc 2.35 (Ubuntu 22.04) = 0x606f0, system = 0x50d70.
4. Stage 2 overflow: doc[1].fn = libc+system, put b"/bin/sh\0" at doc[1].data; R render[1] -> system("/bin/sh") on fd 0.

## Pitfalls
- Output prefixes often carry a TRAILING SPACE (write of "[preview] " length 10) - check rodata length before slicing leaked blobs; an off-by-one makes libc-base assertions fail confusingly.
- count field is a dword but setters write 1 byte (<=255): to leak more than 255 B overwrite the FULL dword via the overflow primitive.
- Payloads may contain NULs freely (raw reads) - only hex-line parsers forbid them.
- Local replica needs the INCLUDED loader: ./ld-linux-x86-64.so.2 --library-path . ./codec (provided-libc + host loader mismatch aborts with stack-smashing at startup).
- If the array slots' fn pointers initialize to a default handler, that handler can be a benign leak itself (prints strnlen(data,40) bytes) - useful for sanity checks.
