---
name: rsa-close-primes-fermat
description: "Use when RSA has close primes p and q; Fermat factorization."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux]
metadata:
  hermes:
    tags: [ctf, crypto, rsa, fermat, factorization]
---

# RSA Close Primes (Fermat Factorization)

Use when an RSA challenge gives N, e, C and p/q are generated close together
(e.g. `q = next_prime(p)`, `q = p + small offset`, "neighbour/neighbor" wording,
`range(5000)` loops calling `next_prime`, or `p, q = getPrime(1024)` twice with a seed).

## Detection

- Challenge text hints q is derived from p ("neighbour", "5000 times", `loop_next_prime`).
- Source code shows `q = next_prime(p)` or similar (difference of thousands, not billions).
- N is large (2048+ bits) but ordinary trial division fails — Fermat targets the
  *difference* between primes, not the size of N.

## Attack

Fermat's factorization: if p and q are close, then for some small k:

    a = ceil(sqrt(N)) + k
    b = sqrt(a^2 - N)   (must be an integer)
    p = a - b, q = a + b

When |p - q| is small, k is tiny (often 0 or a handful of iterations), so it runs
instantly. No factoring of a 2048-bit modulus needed.

## Solver template

```python
from math import isqrt

def fermat_factor(n):
    a = isqrt(n)
    if a * a < n:
        a += 1
    while True:
        b2 = a * a - n
        b = isqrt(b2)
        if b * b == b2:          # b2 is a perfect square
            return a - b, a + b
        a += 1

p, q = fermat_factor(N)
assert p * q == N
phi = (p - 1) * (q - 1)
d = pow(e, -1, phi)
m = pow(C, d, N)
flag = m.to_bytes((m.bit_length() + 7) // 8)
print(flag.decode())
```

## Pitfalls

- `isqrt(n)` may be 1 below the true ceil; always check `a*a < n` and bump by 1.
- Verify with `assert p * q == N` — a wrong (a, b) pair silently gives garbage.
- Use `pow(e, -1, phi)` (Python 3.8+) instead of manual extended gcd.
- The perfect-square test MUST be `b*b == b2`, not just `isqrt` success.
- Sometimes the challenge only prints N (no source): if |p-q| is small, Fermat still
  works — just run it; a quick return means the modulus is vulnerable.

## Variants

- p, q close but not identical: Fermat handles gaps up to ~millions instantly;
  beyond that try `yafu` or lattice/Coppersmith methods.
- Same N reused with two exponents → common-modulus attack (different skill).
- p and q "similar wealth" wording → almost always close-primes/Fermat.
