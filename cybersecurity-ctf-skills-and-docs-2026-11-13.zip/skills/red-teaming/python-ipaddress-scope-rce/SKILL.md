---
name: python-ipaddress-scope-rce
description: "ipaddress.ip_address() to shell: inject via IPv6 scope-id."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux]
metadata:
  hermes:
    tags: [web, python, ctf, command-injection, ipaddress, ipv6, scope-id, rce]
---

# Python ipaddress.ip_address() → shell: IPv6 scope-id injection

Use when an app "validates" user input with Python's `ipaddress.ip_address()`
(or `IPv4Address`/`IPv6Address`) and then interpolates the result into a shell
command (`subprocess.check_output(['/bin/sh','-c', f'... {ip}'])`). Proven on
EQCTF "Ping as a Service" (244, Easy): `ping -c 2 {ip}` → RCE.

## The bypass
`ipaddress.ip_address()` accepts IPv6 **zone/scope ids** (`fe80::1%eth0`), and
the scope part after `%` is NOT character-validated in CPython. Shell
metacharacters in the scope survive validation and land verbatim in the shell
command.

```python
>>> ipaddress.ip_address('fe80::1%1;cat flag.txt')
IPv6Address('fe80::1%1;cat flag.txt')   # scope_id = '1;cat flag.txt'
```
Command becomes: `ping -c 2 fe80::1%1;cat flag.txt` → runs `cat flag.txt`.

Scope character rules (verified):
- ACCEPTED: `; & $() \` >` spaces and most ASCII
- REJECTED: `/` (scope containing a slash → ValueError) — so `>/dev/null` is
  out; `2>&1` is fine.

## Timing pitfalls (app timeouts)
- Ping to a non-responsive host (e.g. `fe80::1`) blocks ~10s → app timeout.
  Use **`::1` (loopback)** as the address: replies instantly, then your
  `;cmd` runs well within typical 8s timeouts: `::1%1;cat flag.txt`.
- Backgrounding (`&`) alone does NOT help: the bg process keeps the stdout
  pipe open, so `check_output()` still blocks until its own timeout. You'd
  need to redirect the bg process's fds (`>/dev/null 2>&1`), but `/` is
  rejected — so prefer the instant-reply address.

## Workflow
1. Read the source; confirm the validation call + the shell interpolation.
2. Test scope acceptance locally first:
   `python3 -c "import ipaddress; print(ipaddress.ip_address('::1%1;id'))"`
3. Send: `curl -G URL --data-urlencode "IP=::1%1;cat flag.txt"` (use
   --data-urlencode / urllib.urlencode — never hand-build the query string).
4. Grep the flag from the response. CWD of the app is often the app dir
   (Docker WORKDIR), so `cat flag.txt` hits the flag file directly.

## Pitfalls
- Do not put `/` in the scope (rejected). For redirections use forms without
  a slash, or avoid them entirely.
- Python version differences are minimal here, but always verify against the
  target's Python (3.10 server vs local 3.13 behaved the same for this).
- If the app validates with `ip_address()` only, integer-string forms
  (`'2130706433'` → 127.0.0.1) also pass — but they carry no injection.
- The injected output goes to check_output's captured stdout — command
  substitution output (`$(...)`) goes INTO the ping argument, not stdout;
  prefer `;`/`&`-style execution for visible output.
