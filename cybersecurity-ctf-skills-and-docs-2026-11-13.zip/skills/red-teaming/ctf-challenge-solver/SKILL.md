---
name: ctf-challenge-solver
description: "Use when solving CTFs and auto-saving exploit skills."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux]
metadata:
  hermes:
    tags: [ctf, pentest, red-teaming, exploit, reverse-engineering, web, pwn, crypto]
---

# CTF Challenge Solver & Skill Collector

Use this skill when tackling CTF tasks, security challenges, or authorized pentesting targets.

## Methodology

### 1. Challenge Workspace & Triage
- Create a dedicated directory: `~/ctf/<event_or_category>/<challenge_name>/`.
- Identify challenge domain:
  - **Web**: Use Scrapling (`get`/`fetch`) to crawl, inspect source code, headers, and endpoints.
  - **Pwn / Binary**: Use terminal (`file`, `checksec`, `strings`) and Ghidra MCP for decompilation.
  - **Reverse**: Use Ghidra MCP for static analysis + terminal debugging.
  - **Crypto / Math**: Use Python with `z3-solver`, `pycryptodome`, `sympy`, or `gmpy2`.
  - **Forensics / Misc**: Use `binwalk`, `exiftool`, `steghide`, or specialized CLI utilities.

### 2. Execution & Exploitation
- Execute tools with real outputs.
- Write exploit scripts in Python (`exploit.py`, `solve.py`) inside the challenge folder.
- Verify flag extraction format (e.g., `flag{...}`, `CTF{...}`).

### 3. Challenge Archival (user preference)
After solving, archive the challenge folder to `~/ctf/<category>/<challenge>/`:
- Copy the original zip + extracted challenge files (e.g., `cp ~/Downloads/<name>.zip ...`).
- Include solution artifacts: solver scripts, exploit, flag, writeup.
- Keep the workspace there so nothing is lost when Downloads is cleaned.

### 4. Automatic Skill Archiving
Upon successfully solving a challenge or discovering a non-trivial attack vector:
1. Extract the core concept/technique (e.g., SQLi bypass, Heap overflow pattern, RSA weakness, custom decoder).
2. Use `skill_manage(action='create')` to save a reusable skill under `red-teaming/` or relevant category.
3. Include:
   - Challenge type & vulnerability pattern.
   - Minimal working code snippet / script template.
   - Key pitfalls and lessons learned.
