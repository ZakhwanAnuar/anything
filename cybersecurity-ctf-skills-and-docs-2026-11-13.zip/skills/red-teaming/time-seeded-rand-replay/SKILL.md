---
name: time-seeded-rand-replay
description: "Replay leaked rand()s from per-second srand(time) seeding."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux]
metadata:
  hermes:
    tags: [ctf, reverse-engineering, crypto, forensics]
---

# Time-Seeded srand(time) Replay

Use when a program does `srand(time(NULL)); x = rand();` inside a loop, logs
the failing `x` values, and the flag is derived from the iteration whose value
meets a condition (e.g. `SHA256(x)` contains a magic substring).

## Pattern

- Each loop iteration reseeds with the current second, so every distinct
  logged `x` corresponds to a distinct timestamp second.
- A log with N distinct values usually means N consecutive seconds
  (`s, s+1, ..., s+N-1`), then the terminating iteration at `s+N`.
- glibc `rand()`/`srand()` are deterministic — call them via `ctypes` to
  match the target exactly (same libc).

## Solver skeleton

```python
import ctypes, hashlib
libc = ctypes.CDLL("libc.so.6")
libc.srand.argtypes = [ctypes.c_uint]
libc.rand.restype = ctypes.c_int

LOG_X = [519457877, ...]          # leaked outputs
TARGET = "a9ba358e"               # magic substring in the winner's hash

def rand_at(seed): libc.srand(ctypes.c_uint(seed)); return libc.rand()

# window: epoch of the logged date +- a few days (timezone tolerance)
for s in range(win_start, win_end):
    if all(rand_at(s + i) == LOG_X[i] for i in range(len(LOG_X))):
        x9 = rand_at(s + len(LOG_X))
        h = hashlib.sha256(str(x9).encode()).hexdigest()
        if TARGET in h:
            print(f"FLAG: EQCTF{{{h}}}")   # adapt prefix
```

## Pitfalls

- The value hashed may go through a `double` with `setprecision(17)` — for
  ints < 2^31, `ostringstream << setprecision(17) << (double)x` prints the
  plain integer, so `str(x)` is correct. Verify by compiling the original
  code rather than trusting the reconstruction.
- glibc `rand()` state: call `srand` immediately before each `rand` when
  testing many seeds (or use the C API from Python via ctypes to avoid
  reimplementing the LCG).
- Log timestamps may be local time; the seed is UTC epoch. Use `date -d
  @<epoch>` to sanity-check the recovered seed against the log's date.
- If consecutive-seconds fails, allow gaps (1..N) between iterations; some
  runs were slowed by output flushing or `uniq`-collapsed logs.
- Always verify: compile the real source (or a faithful repro) with the
  recovered seed and confirm outputs match the log exactly.
