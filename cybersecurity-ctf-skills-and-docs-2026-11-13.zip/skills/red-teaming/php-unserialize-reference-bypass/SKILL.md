---
name: php-unserialize-reference-bypass
description: "PHP unserialize reference (R:) property bypass for web CTFs."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux]
metadata:
  hermes:
    tags: [web, php, ctf, unserialize, deserialization, reference, type-juggling]
---

# PHP Unserialize Reference (R:) Property Bypass

Use when a challenge unserializes user input (often `unserialize(base64_decode($_POST[...]))`)
into a known class and then compares or assigns object properties. Proven on
EQCTF "Vault" (100, Medium): server overwrote our object's `vaultCreds` with
random values, then required `vaultCreds[$z] === guardCreds[$z]` for all z.

## The trick

PHP serialization's `R:n` makes a property a **reference** to the n-th value
parsed so far — two properties share one zval. Any later assignment to one
property writes through the reference, so the other property sees the new
value too.

```php
// server (unknown random values, we must match them):
$obj->vaultCreds = $bankCreds;      // random
if ($obj->vaultCreds[$z] !== $obj->guardCreds[$z]) $open = false;

// our payload: guardCreds references vaultCreds
O:8:"Sequence":2:{s:10:"vaultCreds";a:0:{}s:10:"guardCreds";R:2;}
```
After `unserialize`, `vaultCreds` and `guardCreds` are the same zval. The
server's `$obj->vaultCreds = $bankCreds` updates the shared zval → `guardCreds`
equals `vaultCreds` → all strict compares pass.

Property-order matters for the `R:` index: count values in serialization order
(vaultCreds' `a:0:{}` = value 1, so `R:2` on the next property references it —
verify empirically; both orderings often work, test locally).

## Workflow
1. Read the source; identify the class + which properties are compared/assigned.
2. Replicate the server logic in a local `test.php` (php-cli) with the same
   PHP major version semantics and try payloads BEFORE hitting the remote.
3. Craft `O:<len>:"<Class>":<n>:{s:<klen>:"<prop>";...;s:<klen>:"<refprop>";R:<idx>;}`,
   base64 it, POST it.
4. On success the server usually reflects the flag (or a vault-open state) in
   the HTML — grep `EQCTF{...}` / flag pattern from the response.

## Pitfalls
- `R:` indices are 1-based over parsed values; try both property orderings
  (`R:2` vs the swapped layout) when one fails.
- The object must pass `instanceof <Class>` — keep the class name exact and the
  property names exact (case-sensitive).
- PHP 8.x strict `!==` does NOT block this: the reference makes the values
  literally identical, not merely equal.
- If the server uses `__wakeup()` or properties are private/protected, add the
  correct visibility markers (`s:10:"\0Class\0prop"` for private,
  `s:3:"\0*\0prop"` for protected) — public props here needed none.
- Local php-cli version may differ from remote (8.4 vs 8.1 here) — semantics
  for `R:` references are stable across 7.x/8.x.
- Keep payloads small and POST them in the body (URL-encode); avoid query-string
  length limits.
