---
name: order-by-blind-sqli-topn-oracle
description: "Blind SQLi via ORDER BY sort injection (top-N rows shown)."
version: 1.0.0
---
# Blind SQLi in ORDER BY with top-N row oracle

Pattern: an app stores a user-controlled "sort" value (e.g. report sort preference, often in a signed Flask session cookie) that is concatenated into `ORDER BY <sort>` of a query, and the page renders only the first N rows. Found in CTFs (Sunway "Inject Matcha In Me") and real sort-by-column features.

## Detection
- /preferences-style form with a sort field; report page echoes the sort string and renders top-N rows.
- Generic server message ("rejected that saved preference") = DB error caught => NO error oracle, NO stack trace.
- Valid SQL expressions in sort change which rows appear: try `(CASE WHEN 1=1 THEN col1 ELSE col2 END) ASC` vs `1=0` and compare top-N row ids.
- HTML comments may leak schema (e.g. `staff_recovery(recovery_code CHAR(12))`). Decode the Flask session cookie (base64url) to confirm where sort lives.

## The reliable 1-bit oracle
Sorting by two real columns is ambiguous (both branches can start with the same row). Use a key that flips min-vs-max on the primary key column:

```
sort = (CASE WHEN (<cond>) THEN order_id ELSE -order_id END) ASC
```
- cond TRUE  => first visible row = minimum order_id (e.g. 101)
- cond FALSE => first visible row = maximum order_id (e.g. 108)

Assert first-row id to get one bit. Works whenever row ids are distinct and >1 row exists.

## Exfiltration script shape (Python + requests)
- One requests.Session; POST sort to the preferences endpoint with allow_redirects=True (lands on report page), parse `data-order-id="N"` (or row markup).
- Retry on timeout; small sleep between probes.
- Probe table facts: `(SELECT count(*) FROM t)>=1`, `length(col)` bisection 1..40 with `>= mid` upper-mid split.
- Bisect each char over printable ASCII using `unicode(substr((SELECT col FROM t LIMIT 1),i,1))>=mid` (SQLite).

## Follow-on: cross-host one-time claim (pitfall!)
The exfiltrated secret may unlock a "transition" that issues a SHORT-LIVED, ONE-TIME claim ticket (random token) redeemed at a second host/endpoint ("verification desk").
- Tickets are one-time: a successful redeem burns it. To test payload shape, re-mint a fresh ticket (re-run the transition) instead of guessing with the real one.
- Find the right envelope: JSON `{"ticket": "..."}` with Content-Type: application/json (form-encoded failed/timed out here).
- The flag endpoint returns JSON `{"flag": "...", "ok": true}`.
- Claim URL may be embedded in the vault page as `data-claim-url`.

## Pitfalls
- Do NOT compare full-column sorts as oracle branches; first rows collide. Negated-primary-key discriminator is collision-free.
- ORDER BY injection can't UNION or change the SELECT list; you cannot dump other tables into visible columns — stick to blind subqueries.
- Stacked queries likely blocked (single statement per execute).
- Keep politeness: ~0.3s+ between probes, retry timeouts (server throttled at times).
- CHAR(12) hint == exact length; still verify with length bisection.
