---
name: binary-version-diff-flag
description: "Use when flag is diffused across two versions of a binary."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux]
metadata:
  hermes:
    tags: [ctf, reverse-engineering, binary-diff, elf]
---

# Binary Version Diffing — Flag Diffusion

Use when a RE challenge ships two (or more) versions of a binary ("password gets
more secure over updates", "v1.0.0 vs v1.2.1", "what changed?") and the flag is
hidden in the differences between them.

## Workflow

1. **Extract & triage**: unzip, `file`, run both binaries, `strings -n 5` (grep
   out compiler noise like GLIBC/_/GCC). Passwords often sit in plain .rodata
   (objdump -s -j .rodata) — try them immediately.

2. **Diff the binaries**:
   - `cmp -l a b` (byte-level, octal) or Python byte diff.
   - Group changed bytes; expect: BuildID (20B), version strings, the actual
     password, and — the interesting part — many isolated single-byte diffs.

3. **Decode the diffusion**: in challenges like this, the isolated single-byte
   diffs form an index-permutation cipher:
   - old binary byte = index (a permutation of 0..n-1, maybe non-contiguous)
   - new binary byte = flag character, scrambled by that index
   - sort (old, new) pairs by old value, join new bytes -> flag.

```python
a = open(old,'rb').read(); b = open(new,'rb').read()
pairs = [(i, a[i], b[i]) for i in range(min(len(a),len(b))) if a[i] != b[i]]
single = [(o, old, new) for o, old, new in pairs
          if all(o2 != o-1 and o2 != o+1 for o2,_,_ in pairs)]
flag = ''.join(chr(new) for _, new in sorted((old, new) for _, old, new in single))
```

4. **Filter noise**: exclude rodata ranges holding the version string and
   password diffs (e.g. off < 0x2040) and the 20-byte BuildID block, so only the
   true flag positions remain.

## Pitfalls

- `cmp -l` prints octal; Python diff is easier to reason about.
- Version string diffs ("1.0.0" -> "1.2.1") add fake chars — locate rodata and
  exclude the version/password area.
- The index permutation may be non-contiguous (gaps in the index range) — check
  uniqueness, not contiguity.
- If strcmp target isn't plaintext, disassemble main (objdump -d) and read the
  compared .rodata address directly; obfuscation is usually just a shifted string.
- Verify the flag reads naturally (e.g. "intro to binary diffing" in leet).
