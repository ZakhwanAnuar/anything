---
name: coursestack-ctf-platform
description: "Use when playing a CourseStack-hosted CTF event."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux]
metadata:
  hermes:
    tags: [ctf, coursestack, api, supabase, ctf-platform]
---

# CourseStack CTF platform (API-first playbook)

CourseStack (coursestack.com) hosts CTF events at `<event-domain>/events/<event_id>`
(Huntress CTF 2026 is one instance). Everything the UI does is a JSON API you can call
directly, which is far faster and more reliable than clicking through the site.

## When to Use

- Any CTF or training event whose URL is `*/events/<uuid>` on a CourseStack domain
  (Huntress CTF is the reference instance).
- You need to read lessons, download artifacts, submit answers, or control event VMs
  without clicking through the SPA.
- You are automating/repeating event play and need the scoring semantics and credit rules.

## 1. Authenticate without anyone's password

The session is a **Supabase** session stored in NON-HttpOnly chunked cookies
(`sb-auth-auth-token.0` / `.1`) on the event domain. If the player is logged in on their
own browser, read the cookies straight out of the profile:

```python
import sqlite3
# flatpak Firefox; native Firefox is ~/.mozilla/firefox/<profile>/
db = "~/.var/app/org.mozilla.firefox/config/mozilla/firefox/<profile>/cookies.sqlite"
con = sqlite3.connect(f"file:{db}?immutable=1", uri=True)
ck = "; ".join(f"{n}={v}" for h, n, v in con.execute(
    "select host,name,value from moz_cookies where host=? and name like 'sb-auth-auth-token%'",
    ("<event-domain>",)).fetchall())
```

Send as `Cookie:` on every `/api/...` call. Values rotate: on 401 re-read the profile,
don't go debugging the request.

## 2. API map (cookie-authenticated)

| Purpose | Request |
|---|---|
| Event + curriculum | `GET /api/student/events/<event_id>` |
| **All lessons + questions + file ids** | `GET /api/student/events/<event_id>/take` |
| Download lesson artifact | `GET /api/student/content/<playthrough_id>/files/<file_id>` |
| Submit a native answer | `POST /api/student/content/<playthrough_id>/lessons/<lesson_id>/submit-question` body `{"questionId":"<qid>","submission":"<value>"}` |
| VPN profile | `GET /api/student/courses/<playthrough_id>/vpn` |
| List systems/VMs | `GET /api/student/courses/<playthrough_id>/systems?courseSystemIds=["<id>"]` |
| Power a VM | `POST /api/student/courses/<playthrough_id>/systems/<system_id>/power` body `{"power":"on"|"off"}` |
| Get a VM's web URL | `POST .../systems/<system_id>/connect` body `{"connectionIndex":0,"isNew":true}` -> `{"url":"https://<id>.proxy.coursestack.com/coursestack-auth#token=..."}` |
| Scoreboard | `GET /api/student/events/<event_id>/scoreboard` |

`/take` is the single most useful call: it returns the whole curriculum with rendered
markdown, `file` items (artifact ids) and every question with `id`, `points`,
`match_type` and `state`.

## 3. Scoring semantics that save hours

- **`state` is the ground truth.** A question is `unanswered` or `correct`; there is no
  partial credit shown. Poll `/take` and trust only that — never a sub-agent's claim that
  "it's done".
- **`match_type: "exact"`** questions (e.g. a flag hidden in the site's DOM) are submitted
  with `submit-question`; the response includes `result.is_correct`.
- **`match_type: "dynamic"`** questions are completed by the event's own challenge service
  (Huntress CTF 2026 uses a "Game Master"). Do NOT try to `submit-question` those — the
  service marks them correct itself once it accepts your answer.
- Failed attempt counter is per question; wrong guesses don't lock you out but do waste the
  service's per-attempt material.

## 4. VM / credit mechanics (when the event bills compute)

- VMs have `gbPerRuntime` (credits/hour) and the event grants an allowance; the platform
  **never exposes a balance endpoint** — the only reliable signal is the power response:
  `{"error":"bad_request","message":"You are out of credits"}`.
- Allowances can refill daily on a schedule tied to the challenge drop (Huntress: 9:00 AM
  ET). Read the event's own onboarding lessons for the stated rule instead of guessing.
- `POST .../launch` returns `{"success":true}` even when the system stays stopped — it is
  NOT a way around an exhausted allowance.
- The VM's UI is reached through a public proxy domain `https://<id>.proxy.coursestack.com`;
  the `coursestack-auth` fragment sets a `token` cookie, then reloads. That path needs no
  VPN.

## 5. Automation that protects the allowance

If you schedule a recurring agent to play the event:
1. **Check for open work FIRST** (`/take`) and exit without starting a VM if nothing is
   unanswered or the event has ended.
2. **Prefer any free path** the event documents before spending credits.
3. **Power the VM off in a finally-style step**, success or failure. An idle VM is what
   exhausts a daily allowance — the actual work is minutes.
4. Keep run-to-run continuity on so it doesn't redo yesterday's challenges.

## Pitfalls

- The event domain may be a thin SPA: `curl` of a lesson URL returns a 404 error page and
  `__NEXT_DATA__` holds only public data. Use the API, or a real browser.
- `/systems/<id>/connect` returns 400 "Old app version detected" unless the body is the
  full `{"connectionIndex":0,"isNew":true}`.
- `course_playthrough_id`, `system_id` and artifact `file_id`s differ per event AND per
  playthrough — read them from `/take`, never hardcode another player's.
- Flags/answers are frequently **dynamic per team**. Never reuse another identity's
  artifact, answer id or flag; cross-identity values never validate.
