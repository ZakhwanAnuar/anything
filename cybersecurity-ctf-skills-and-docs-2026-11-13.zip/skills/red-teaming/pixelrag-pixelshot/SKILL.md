---
description: Use when a web CTF page must be read as an image.
name: pixelrag-pixelshot
---

# PixelRAG / pixelshot — visual page capture (web CTF)

Renders documents to tiled JPEGs and searches over images (pixel-native; no MCP server — CLI only). Use when text-mode fetches (scrapling, web_extract) fail or lose structure: JS/SPA-gated content, visual captchas, tables/charts/infographics, layout-dependent flags, auth'd dashboards.

## Install state (already done)
`uv tool install pixelrag` → executables in ~/.local/bin: `pixelshot` (renderer) and `pixelrag` (pipeline entrypoint — NOT the renderer). Background shells: export PATH=$HOME/.local/bin:$PATH; uv itself is /home/kubesame/.hermes/bin/uv.

## Render a page
    pixelshot <URL|pdf|html-file> -o OUTDIR [opts]

- Default backend `cdp` launches a throwaway headless Chrome (auto-found on this host); `--backend playwright` is the alternative.
- `--wait-network-idle`: SPA/JS content loaded after the load event (networkidle2, capped 12s). Enable for JS-heavy pages.
- `--cdp-url http://127.0.0.1:9222`: attach to an ALREADY-RUNNING Chrome/Brave with its session (cookies/logins) → authenticated pages render; only its own tab is closed. Env var PIXELSHOT_CDP_URL.
- Tall pages split at 8192px (--tile-height); viewport 875px wide (--viewport-width). PDFs render at 200 DPI (--dpi).
- Batch several URLs in one invocation; 4 parallel workers default.

## Output + reading the tiles
Output: OUTDIR/<name>.png.tiles/{tile_0000.jpg, ..., tiles.json}. tiles.json = {url, page_height, tiles[]}.
Hermes cannot view images natively: after rendering, call vision_analyze on EACH tile (question: extract all visible text/flags, describe layout). A flag or answer can span tiles — check every tile and cross-reference tiles.json page_height. For CAPTCHA/image-flag challenges, tile then vision_analyze is the whole trick.

## Hosted visual search (no key, no setup)
    curl -s -X POST https://api.pixelrag.ai/search -H "Content-Type: application/json" -d '{"queries": [{"text": "..."}], "n_docs": 5}'
Serves a pre-built 8.28M-Wikipedia index; returns scored hits with tile paths. Image queries supported. Browser UI: pixelrag.ai. Mostly useful for wiki-domain reference, not for a CTF target itself.

## Full local pipeline (rarely needed)
`pixelrag chunk | embed | build-index | index | monitor | serve` — heavy; only when indexing your own corpus locally.

## Workflow order
Text-mode parse first (scrapling MCP / agent-reach Jina), pixelshot as the visual fallback when text comes back empty/garbled or the answer lives in rendered layout.
