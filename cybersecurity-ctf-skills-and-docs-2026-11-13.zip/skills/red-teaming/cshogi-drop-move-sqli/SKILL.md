---
name: cshogi-drop-move-sqli
description: "Use when exploiting SQLi in shogi/cshogi web CTFs."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux]
metadata:
  hermes:
    tags: [ctf, web, sqli, sqlite, shogi, cshogi, blind-sql-injection, red-teaming]
---

# cshogi Drop-Move SQL Injection

Exploit web apps that use cshogi (the Python shogi library) where an unsanitized
move string reaches an SQL query (e.g. `main.py` f-strings the move into an INSERT).

## Core primitives

### 1. USI drop-move leniency (the injection vector)
cshogi `Board.move_from_usi()` (and module `cshogi.move_from_usi` in 0.9.x) only
inspects the FIRST 4 chars of a DROP move and ignores everything after. So
`S*5e' OR 1=1 --` parses as a legal silver drop while the tail is free SQL.

- Drop format: `<PIECE>*<file><rank>` where PIECE in {P,L,N,S,G,B,R} (no King).
- Normal (non-drop) moves are STRICT: exactly 4 chars, or 5 ending in `+`
  (promotion) — cannot carry a payload.
- Confirm against the pinned cshogi version (0.9.7 == 1.0.4 behaviour here).

### 2. A drop needs a piece in hand
You must capture a piece before you can drop it. Playing a real game to capture
is the hard part — replicate the server AI locally with cshogi and BFS for the
shortest capture sequence, then replay those exact USI strings.

### 3. cshogi PieceType vs HandPiece order mismatch (gotcha)
cshogi `PieceType`: Pawn=1 Lance=2 Knight=3 Silver=4 Bishop=5 Rook=6 Gold=7.
cshogi hand array (`pieces_in_hand`): [HPawn,HLance,HKnight,HSilver,HGold,HBishop,HRook].
So `hand_index = piece_type - 1` is WRONG for Bishop/Rook/Gold:
  Bishop(5)-1=4 -> checks GOLD slot; Rook(6)-1=5 -> BISHOP; Gold(7)-1=6 -> ROOK.
Only Pawn/Lance/Knight/Silver map correctly. A captured bishop cannot be dropped
by such an app — capture a SILVER (no drop restriction, unlike pawn's nifu and
lance/knight's back-rank limits).

### 4. SQLite boolean oracle (SQLite never errors on 1/0!)
`SELECT 1/0` returns NULL in SQLite (no error). Use integer overflow instead:
`abs(-9223372036854775808)` raises `OperationalError: integer overflow`.

Oracle payload for an INSERT `VALUES ('{user_id}', '{move}', datetime('now'))`:
```
<DROP>', (SELECT CASE WHEN <cond> THEN datetime('now')
                  ELSE CAST(abs(-9223372036854775808) AS TEXT) END)) --
```
- cond true  -> HTTP 200 (commits the drop move)
- cond false -> HTTP 500 (integer overflow)

## Blind extraction recipe
- `length((SELECT move FROM t WHERE user_id='admin' LIMIT 1)) >= N` for length.
- `unicode(substr((SELECT move FROM t WHERE user_id='admin' LIMIT 1),POS,1)) >= M`
  binary-search each char over ASCII 32..126.
- Verify final candidate with an exact-equality query.

## Pitfalls
- A successful (200) query COMMITS the drop move -> the piece is consumed and the
  board advances; re-capture before the next query (or reset + replay the capture
  sequence). A failed (500) query leaves the DB unchanged -> piece still in hand,
  can retry immediately.
- Heavy sequential load triggers transient HTTP 400s (drop rejected). Back off and
  retry; on persistent 400 default the query result rather than corrupting the
  binary search (this silently yields wrong characters).
- Werkzeug debug page (debug=True) shows a PIN-locked console; RCE needs machine-id
  + MAC, usually not worth it when blind SQLi already works.
