---
name: php-lfi-source-read
description: "Use when PHP LFI gives source reads; flags hide in comments."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux]
metadata:
  hermes:
    tags: [web, php, ctf, lfi, file-inclusion, source-code, php-filter]
---

# PHP LFI → Source Read → Flag in PHP Comments

Use when a PHP app does `include($_GET['page'])` (or similar) with no
filtering. Proven on EQCTF "King Brews" (100, Easy): flag hidden as a PHP
comment in menu.php, only visible by reading source.

## Core technique
`include($page)` = arbitrary file INCLUDE (executes PHP) + arbitrary file READ
via the base64 filter wrapper:
```bash
curl "http://HOST/?page=php://filter/convert.base64-encode/resource=menu.php" \
  | grep -oE '[A-Za-z0-9+/]{50,}={0,2}' | head -1 | base64 -d
```
Read EVERY page's source (index.php, home.php, menu.php, ...) — flags are
often planted as `<?php //flag=EQCTF{...} ?>` or `<!-- flag=... -->` comments.
PHP comments are stripped server-side, so the rendered page never shows them —
only a source read does. Grep the decoded sources for `flag`, `EQCTF`, `CTF{`,
`secret`, base64 blobs, and hardcoded creds.

## Existence oracle (no directory listing)
With `display_errors=On`, include failures print
`Warning: include(X): failed to open stream: No such file or directory`.
Probe candidate paths and classify: warning → missing; no warning → exists.
This turns blind LFI into a file-existence oracle. Write a small loop over a
wordlist (flag.txt, .env, .htaccess, admin.php, config.php, /etc/passwd, ...).

## RCE escalation quick checks (in order of cheapness)
- `php://input` with POST body PHP — needs allow_url_include=On (usually Off).
- `data://text/plain;base64,...` — same requirement.
- `/usr/share/php/pearcmd.php` include — classic php:apache RCE if PEAR present.
- Apache log poisoning (`/var/log/apache2/access.log`) — often dead in Docker
  (logs go to stdout; check with the existence oracle first!).
- `/proc/self/environ` — usually Permission denied.
- Read `/proc/self/mountinfo` to spot mounted flag volumes.

## Pitfalls
- Truncate greps with care: the flag line can be the very line `head -20` cuts.
  Grep decoded sources fully before moving on.
- `include('relative.php')` resolves against PHP's CWD (= docroot typically) —
  absolute paths `/var/www/html/...` also work.
- Filter chains (`convert.base64-encode|convert.base64-decode`) are for
  double-encoded cases; plain base64 encode is enough for source reads.
- Keep the payload in the GET param as-is; URL-encode only the `/` and `:` as
  needed (or use `--data-urlencode`/urllib quote with safe="/").
- If include fails on a path, the warning text (when visible) tells you
  missing vs permission-denied vs is-a-directory.
