---
name: m0dul0ctf-esp32-ble-board
description: "Use when solving M0DUL0CTF ESP32 BLE CTF board challenges."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux]
metadata:
  hermes:
    tags: [ctf, hardware, ble, esp32, gatttool, bleak]
---

# M0DUL0CTF ESP32 BLE board

On-site ESP32 board running a 20-challenge BLE CTF course ("Score: X/20"). One 30-minute session per team. gatttool is NOT installed on the host -> drive GATT with bleak from the `hwctf` venv (`source ~/.local/venvs/hwctf/bin/activate`), which is rootless-safe over BlueZ. Old bleak there: RSSI lives on `advertisement_data.rssi`, NOT `device.rssi` (AttributeError storm otherwise).

## Finding YOUR board among many

Every team station has a board advertising name `M0DUL0CTF` with service UUID 000000ff-0000-1000-8000-00805f9b34fb, so a scan shows several. They advertise in BURSTS (silent minutes at a time) — scan repeatedly; a long-running watcher loop that re-scans every ~8 s catches them. Pick by RSSI: your board sits at your table (~-40 dBm) while neighbours are -75 dBm or worse. Example our-board MAC: 8C:94:DF:68:FC:3A.

## Verified solve flow (BLE Flag 01, onboarding)

1. Read ff03 @ value handle 0x002d: the unprotected record = a 20-char lowercase hex ASCII string (per-board value differs).
2. Write that ASCII string to the submission char ff02 @ 0x002b (value text "Write Flags Here", props read,write) with `write_gatt_char(h, data, response=True)`.
3. Read ff01 @ 0x0029 to confirm score increments ("Score:1 /20").
4. Wrapped platform flag = M0DUL0CTF{<the 20 hex chars>}.

Writeup handle refs (score 0x002a, submit 0x002c) are generic and may be off by one from the live board — always enumerate first and target by characteristic role, not the writeup's raw handle.

## GATT map of the 0x00ff challenge service (verified)

- ff01 @0x0029 read  = score "Score: X/20"
- ff02 @0x002b read,write = "Write Flags Here" (flag submission char)
- ff03 @0x002d read  = flag-01 record (20 lowercase hex chars, unprotected)
- ff04 @0x002f read  = "MD5 of Device Name" (key material hint for later flags)
- then per-challenge task chars, mostly readable INSTRUCTIONS, e.g.:
  0x0031 rw "Write anything here" / 0x0033 rw "...ascii value yo..." /
  0x0035 rw "...hex 0x07..." / 0x0037 r "Write 0xC9 to handle 58" (target ff09 @0x0039 write-only) /
  0x003b rw "Brute force my value 00 to ff" / 0x003d r "Read me 1000 times" /
  0x003f rwn notify "single notification" / 0x0044 rwi indicate handle 0x0045 /
  0x0047 rwn notify "multi notifications" / 0x004c rwi indicate handle 0x004d /
  0x004f r "Connect with BT MAC 11:22:33:44:55:66" / 0x0051 r "MTU to 444" /
  0x0053 rw "Write+resp 'hello'" / 0x0055 rw "No notifications here! really?" /
  0x0057 brwn "So many properties!" / 0x0059 r "md5 of author's github handle"
- Full char list: ff01..ff17 value handles 0x0029..0x0059 (see ~/ctf/hardware/ble-flag-01/ for probe scripts).

## Firmware = hackgnar ble_ctf (open-source, DEF CON 29 workshop)

This board runs hackgnar/ble_ctf ESP32 firmware, renamed from BLECTF to M0DUL0CTF. Public full solution writeups: github.com/camercu/ble-ctf README, jasper.la/posts/ble-ctf-write-up, rossmarks.uk/blog/ble-ctf-walkthrough.

- EVERY answer/flag = md5 truncated to the FIRST 20 hex chars ("avoid MTU limits").
- All flags submitted to ff02 (0x002b) as the 20 ASCII hex chars (gatttool needs them hex-encoded; bleak sends ASCII bytes directly).
- M0DUL0CTF platform flag N == hackgnar challenge N+1 (platform drops the original "flag given in description"). Verified: platform 01 (d205303e099ceff44835) = hackgnar F2; platform 02 md5-of-advertised-name = hackgnar F3.
- THIS BOARD'S ATTRIBUTE HANDLES ARE GLOBALLY SHIFTED -1 vs the hackgnar writeups (score 0x29 vs 0x2a, record 0x2d vs 0x2e, etc.). Challenge texts that hardcode a handle ("Write 0xC9 to handle 58") point at the ORIGINAL numbering — map by characteristic ROLE on this board, not the literal number.
- Sequence (our handles): 01 record ff03@0x2d -> read. 02 md5(advertised name)[:20]. 03 GATT Device Name char 0x2A00@0x0015 value (2b00042f7481c7b056c4b410d28f33cf) truncated to 20 = 2b00042f7481c7b056c4. 04 ff05@0x31 write any text -> read back flag. 05 ff06@0x33 write ascii "yo". 06 ff07@0x35 write hex 07. 07 ff08@0x37 text says write 0xC9 to handle 58 -> real target is ff09@0x39 (write-only) on this board; flag = re-read ff08. 08 ff0a@0x3b brute force single byte 00..ff, read until text changes. 09 ff0b@0x3d read 1000x. 10 ff0c@0x3f notify x1 (write 0100 to CCCD, listen). 11 ff0d/ff0e@0x42/0x44 indicate (0200). 12 ff0f@0x47 multi notify. 13 ff10/ff11@0x4a/0x4c multi indicate. 14 ff12@0x4f change controller BD_ADDR to 11:22:33:44:55:66 (root needed). 15 ff13@0x51 MTU 444. 16 ff14@0x53 write+response "hello". 17 ff15@0x55 hidden notify (no notify prop but write+listen works). 18 ff16@0x57 multi props -> combine read+notify halves. 19 ff17@0x59 md5 of author github handle.

## Pitfalls

- Don't trust a single scan pass: boards stop advertising for minutes (power saving or while connected). Watcher loop, then strike fast — connect the moment the right RSSI appears.
- bleak connect MTU 23 default; fine for short writes, raise MTU for challenges that need bigger payloads.
- Handle sweep with read_gatt_char(int) only returns real characteristic value handles; write-only chars raise on read — read errors are expected there.
- Char values are often literal ASCII task text; a value whose ASCII decode is 20 lowercase hex chars IS the record for flag 01, not an instruction.
- Verify success by re-reading score (0x0029), never assume the write landed.
- Duplicated/repeated task chars (0x0044/0x0047 vs 0x004c etc.) differ only in wording — the board is just verbose; the char you must act on is named in the text ("handle 0x0045", "me" = the char itself).
