---
name: toctou-shared-mem-ledger-race
description: "Use when a binary TOCTOU-races a MAP_SHARED record length."
version: 1.0.0
author: kubesame
license: MIT
platforms: [linux]
metadata:
  hermes:
    tags: [ctf, pwn, toctou, race, mmap, shared-memory, stack-overflow, canary, rop, libc]
---

# TOCTOU shared-memory ledger (stack overflow via record length flip)

Use when a pwn/CTF binary mmaps a file (/dev/shm or any path) MAP_SHARED, validates a length/state field in the mapping, then re-reads it after an I/O boundary (TOCTOU); or when a PEEK-style printer write()s MORE than it memcpy'd (stack leak). Known instance: SunCTF "Being Chalant Is Cool" (ledger, OPEN/POKE/PEEK/RENDER/GO commands).

## Challenge anatomy (ledger)
- OPEN <token>: token must be DIGITS (ctype isdigit bit-test 0x08). Builds /dev/shm/bc_<token>, open(O_CREAT|O_RDWR), ftruncate(0x1000), mmap(0x1000, MAP_SHARED). Record struct: magic 'TFHS'@0, version@4, LEN@8, record data@0x10.
- POKE <off_dec> <hex>: writes one byte per hex pair at map+offset; offset parsed DECIMAL (strtoul base 0); bounds < 0x1000. Input lines capped at 255 chars -> payloads > ~120 B go in ~0x60-byte chunks via successive POKEs at offset+i.
- PEEK: __memcpy_chk(stack, map+0x10, min(len,0x40), 0x40) but then write(1, stack, FULL len) -> arbitrary-size STACK LEAK. From dump start: canary @+0x48, saved rbx @+0x58, rbp @+0x60, ret-into-main @+0x68. pie_base = ret - 0x18e5 (site after `call fcn.0000155c`).
- RENDER: checks len@map+8 <= 0x40, prints "validated; send GO", readline("GO"), then RE-READS len@map+8 and runs an UNBOUNDED byte-loop copy map+0x10 -> stack (no __memcpy_chk).
- TOCTOU: the two len reads straddle the blocking GO read. A 2nd connection with the SAME token maps the same file and flips len@map+8 to 0xff0 while conn 1 blocks on GO -> overflow. Window is arbitrarily long (conn 1 waits for your GO) - no tight race needed.
- Overflow payload offsets (RENDER frame): 0x48 pad + canary + 0x50 saved-rbx junk + ret @0x58, first gadget arg @0x60. Patch main's own canary at payload+0x248 too (main canary == RENDER canary, same process; copy zero-fills the rest of main's frame, which is fine - locals re-init per command).
- Register state at first gadget: rdx == 1 (RENDER's trailing newline print set it via strlen/write), NOT 6. Trick: leak N bytes with N x [pop rsi; addr+k; write@plt] (set pop rdi; 1 once - rdi persists; rdx stays 1). 6 calls -> full 48-bit GOT pointer.
- system() entry alignment: empirical here = rsp%%16==0 at entry (ONE ret gadget; two rets crash).
- Gadgets (PIE-relative): pop rdi; ret 0x19d8, pop rsi; ret 0x1427, ret 0x101a, write@plt 0x1140, main_loop(re-prompt) 0x18e5, write@got 0x3f68. Full RELRO but GOT is readable.

## Exploit flow (verified end-to-end)
1. conn A: OPEN <random 10-digit token>; POKE 8 00080000 (len=0x800, 4 bytes LE); PEEK -> dump; canary=dump[0x48:0x50], pie=u64(dump[0x68:0x70])-0x18e5.
2. Write payload chunks at map offset 16 (decimal); POKE 8 10000000 (len 0x10); RENDER; conn B: OPEN same token, POKE 8 f00f0000 (len 0xff0); A sends GO. Output after GO: "[*] receipt "(12 chars) + 6 record bytes + "\n" + ROP output.
3. Round 1 chain = [pop_rdi,1] + 6x[pop_rsi, got_write+k, write_plt] + [main_loop] -> leaked bytes -> write addr -> libc base (subtract provided libc's write offset).
4. Round 2 chain = [pop_rdi, libc+binsh, ret, libc+system]; repeat flip; send shell commands on conn A (shell reads fd 0 = socket).

## Pitfalls
- POKE offsets are DECIMAL: "POKE 10 ..." writes at 0xa, not 0x10; partial-width len writes leave stale high bytes -> garbage length dword.
- Length-field writes need all 4 bytes LE: len 0x10 -> "10000000", 0xff0 -> "f00f0000", 0x800 -> "00080000".
- Copy length must keep src inside the 0x1000 mapping (len <= 0xff0 = 0x1000-0x10) else SIGSEGV before the epilogue.
- Provided libc under a NEWER host ld.so can abort at startup ("stack smashing detected", TLS/canary mismatch): test the mechanism with the system libc locally; pull symbol offsets from the provided libc file (readelf -sW / nm -D; verify /bin/sh via objdump of system()'s lea rip ref, not raw find()).
- One-shot vs fork-per-conn deployment is irrelevant: the PEEK leak is in-process; the helper conn only does dumb POKEs.
- /dev/shm is world-visible on shared CTF hosts: always use a fresh random DIGIT token.
- Local test = spawn the binary twice with pipes, same token; /dev/shm is world-writable even for rootless users.
- Verify shared mapping propagation first (A POKE content, B PEEK) if the remote may load-balance across containers.
