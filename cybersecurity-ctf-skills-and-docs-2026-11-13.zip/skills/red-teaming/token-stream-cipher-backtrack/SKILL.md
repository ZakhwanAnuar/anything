---
name: token-stream-cipher-backtrack
description: "Use backtracking to decode ambiguous cipher token-streams."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux]
metadata:
  hermes:
    tags: [ctf, reverse-engineering, crypto]
---

# Token-Stream Cipher Inversion with Backtracking

Use when a binary transforms input into a mixed token stream of variable
lengths — e.g. Bacon's cipher: letters (a-z) become 5-char groups from a
2-letter alphabet (0/1 mapped to custom chars like w/e), while other chars
become a single char XOR-chained with the previous ORIGINAL char, and the
first 2 chars pass through literally. Then the result is base64'd and
compared to a target string.

## Why backtracking is needed

The encoding is ambiguous: an XOR output byte can itself be one of the
Bacon letters (w/e), so a w/e run can be parsed either as 5-char groups OR
as individual XOR chars. Many parses are self-consistent — only one is the
intended flag. Verification by RE-ENCODING is the only ground truth.

## Workflow

1. Find the target string: it's a global std::string initialized in
   `_GLOBAL__sub_I__...` from a .rdata constant — decompile the static
   initializer, read the constant from the file (map VA->file offset via
   the section table), don't hand-transcribe.
2. Reimplement BOTH transforms exactly from the decompiled code
   (encrypt and the base64-like encode, incl. its custom alphabet/bit
   accumulator).
3. Backtracking parser with pruning:

```python
def solve(pos, prev, out):
    if pos == len(E):
        return [out]
    res = []
    ch = E[pos]
    if ch in b"we":                       # Bacon group OR xor char
        if pos + 4 < len(E) and all(c in b"we" for c in E[pos:pos+5]):
            v = int(E[pos:pos+5].decode().translate(str.maketrans("we","01")), 2)
            if v <= 25:                    # only a-z are valid letters
                letter = chr(ord('a') + v)
                res += solve(pos + 5, ord(letter), out + letter)
        c = ch ^ prev
        if not (0x61 <= c <= 0x7A) and 0x20 <= c <= 0x7E:   # xor only for non-letters
            res += solve(pos + 1, c, out + chr(c))
    else:
        c = ch ^ prev
        if not (0x61 <= c <= 0x7A) and 0x20 <= c <= 0x7E:
            res += solve(pos + 1, c, out + chr(c))
    return res
```

   Rules that make the parse self-consistent with the encoder:
   - XOR branch valid only if decoded char is NOT in the Bacon letter set
     (the encoder would have group-encoded it otherwise).
   - Bacon group valid only if decoded 5-bit value <= 25 (a-z).
   - Prune on non-printable output chars.
4. VERIFY: for each candidate, re-run encrypt+encode and keep only those
   equal to the target. Pick the natural-reading one (EQCTF{...}).
5. Confirm by running the real binary with the flag.

## Pitfalls

- First N chars (here 2) pass through literally — seed the parser with them.
- XOR chain uses the previous ORIGINAL input char, so after a Bacon group
  the chain key is the decoded letter, not the w/e text.
- The base64 target string may be 140+ chars; always extract it from the
  binary file bytes, never retype it (easy to corrupt).
- Multiple candidates WILL re-encode identically (non-injective cipher) —
  that's expected; the intended flag is the human-readable one.
- Windows PE: use Ghidra headless (load via POST /load_program; imports
  via MCP need GUI) + wine to run the exe for final verification.
