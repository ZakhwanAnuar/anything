---
name: lwe-structured-matrix-sudoku
description: "Use when LWE has a Sudoku-structured unknown public matrix."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux]
metadata:
  hermes:
    tags: [ctf, crypto, lwe, lattice, sudoku, z3, pqc]
---

# LWE with Unknown/Structured Public Matrix (Sudoku-style)

Use when a PQC/crypto challenge encrypts as `t = A*s + e` (LWE pattern: public matrix A
times secret vector s plus small error e), but A is only partially known — blanks/None
cells, or entries expressed via unknown constants (x, y, z) — and the blanks are governed
by a puzzle structure (Sudoku: rows/cols/boxes each contain the same candidate set, or
fixed row/col/box sums).

## Detection

- Source shows `t = A*s + e` with a small random error vector, `s` containing
  `ord(char)` / `bytes_to_long` of flag pieces.
- Matrix A has `None`/blank cells or symbolic entries like `2*x+11*y`, `-3*z`.
- Text hints at Sudoku / puzzle rules / magic sums ("every real candidate is presented",
  "each row, col, box sums to 1166").

## Attack (two stages)

### Stage 1 — Recover the full matrix A via constraint solving (z3)

Model the puzzle as a CSP:
- Candidate values `c0..c3` are distinct and sum to the magic total
  (e.g. 1166) since every row/col/box is a permutation of them.
- Every cell ∈ {c0..c3}; each row, each col, each box (2x2 for 4x4) all-distinct.
- Fixed cells from the code (e.g. `A[0][1] = 2*x+11*y`, `A[2][2] = 8192`).
- "Every real candidate is presented" → each candidate must equal at least one
  of the given (non-blank) entries.

Enumerate solutions with a blocking clause; even if candidate *ordering* varies,
the matrix itself is usually unique. Verify fixed cells numerically (e.g.
`2*1337 + 11*(-576) == -3662`).

### Stage 2 — Recover s (hence flag) from the LWE samples

With A known and invertible, solve exactly over rationals:
- `Ainv = inv(A)` (exact Fraction arithmetic).
- For each sample t: `s = Ainv * t`, round each component to nearest int.
- Sanity-check: `a,b,c` in the randint range (e.g. [1,50]), 4th component in
  printable ASCII, and residual `|t - A*s| < bound` (error vector small).
- 4th component is `ord(char)` → join chars → flag.

Lattice reduction (LLL/Babai) is the textbook LWE solver, but when the secret
components are tiny integers and the error is small, direct inversion + rounding
works and is simpler. Pull out LLL only if rounding fails.

## Solver template (core)

```python
from fractions import Fraction

A = [[...]]  # recovered matrix
# exact inverse
Ainv = inv_matrix(A)  # Gauss-Jordan over Fraction
for t in samples:
    t = [Fraction(v) for v in t]
    s = [sum(Ainv[i][j]*t[j] for j in range(4)) for i in range(4)]
    s = [round(float(v)) for v in s]
    # verify: 1<=s[0..2]<=50, 32<=s[3]<=126, residual small
    ch = chr(s[3])
```

## Pitfalls

- Do NOT assume A is fully known — check for None cells first.
- Row/col/box sums alone may be underdetermined; the "candidates are a permutation"
  + "all candidates presented" constraints are what pin down the matrix.
- Candidate order in z3 output may vary between solutions — compare the actual
  matrix, not the candidate labels.
- Use exact `Fraction` for the inverse; float rounding of big entries can drift.
- Residual check catches wrong A: if rounding fails, re-examine Stage 1.
