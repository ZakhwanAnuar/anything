---
name: lcg-nonce-schnorr-key-recovery
description: "Schnorr/ECDSA nonces follow an LCG; recover the private key."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux]
metadata:
  hermes:
    tags: [ctf, crypto, schnorr, ecdsa, lcg, nonce]
---

# LCG nonce reuse -> Schnorr private key recovery

When several Schnorr (or ECDSA) signatures share a public key and the nonces k_i
follow a linear congruential generator k_{i+1} = A*k_i + B mod Q with unknown
A, B, k0, the private key x is recoverable without knowing any nonce. Works even
when one step is skipped between two signatures ("solar flare" gap), as long as
the skip count is known.

## Setup
- Group: prime P = 2Q + 1 (safe), G generator of order Q, Y = G^x public key.
- Signature: R = G^k; e = SHA256(msg || "|" || decimal(R)) mod Q; s = k + e*x mod Q.
- Verify: G^s == R * Y^e mod P. Confirm all sigs validate first.

## Core trick
Every nonce is affine in the secret: k_i = s_i - e_i*x mod Q. Substituting into
LCG relations eliminates A and B, leaving polynomials in x alone over GF(Q):

1. Adjacent-difference ratio: for a triple of consecutive single-step sigs,
   j_i = k_{i+1} - k_i is affine in x, and A = j_{i+1}/j_i. Two such triples
   (same A) give j1*j2 = j0*j3  -> a QUADRATIC in x (cross-multiplied).
2. Any skipped-step gap (t steps) gives a higher-degree extra relation
   (cubic for a double step) used to filter the quadratic's two roots:
   for a double step 2->3: (k3-k2)*j0^2 = j1^3 + j1^2*j0, with j0=k1-k0, j1=k2-k1.

Solve the quadratic mod Q: x = (-b +/- sqrt(b^2-4ac)) / 2a. sqrt via Tonelli-
Shanks; when Q % 4 == 3 the fast path is pow(a, (Q+1)//4, Q). Keep the unique
root that zeroes the higher-degree relation. (If the x^2 coefficient vanishes the
quadratic degenerates to linear - handle a==0.)

## Validation (always do this)
- G^x == Y mod P.
- Recover A = (k2-k1)/(k1-k0), B = k1 - A*k0; replay EVERY LCG step for all
  consecutive sig pairs AND the t-step gap: k_after = A^t*k_before + B*(A^t-1)/(A-1)
  (for t=2: A*(A*k+B)+B). Every relation must hold.

## Pitfalls
- Do the algebra as coefficient lists over GF(Q) (mod Q at every op); a helper
  that returns 3 coefficients into an unpack expecting 2 silently breaks.
- e_i = H(...) mod Q, s_i = response; compute both from the exact message text
  and decimal commitment R ("|" separator, decimal not hex).
- Direction of LCG matters: k_{i+1} = A*k_i + B; pick j_i = k_{i+1} - k_i so
  A = j_{i+1}/j_i consistently.
- Count signature indices from 0; map logs to sigs carefully when logs are skipped.

## SunCTF proof-of-solve (proof.chal) submission
- GET /v1/<category>/<name>/start -> {token, nonce, proof_format}.
- proof = hex(HMAC-SHA256(key=SHA256(decimal_solution_bytes).digest(),
  message=utf8("proof-v1|<name>|<token>|<nonce>"))) - the <challenge> field is
  just the short slug ("kryptonite"), NOT "crypto/kryptonite".
- POST JSON {token, response} to /v1/<category>/<name>/claim; 200 returns the flag.
- Full writeup + scripts: ~/ctf/crypto/kryptonite/ (solve.py, key.txt, README.md).
