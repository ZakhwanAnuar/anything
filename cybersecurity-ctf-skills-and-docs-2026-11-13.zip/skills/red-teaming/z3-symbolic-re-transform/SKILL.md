---
name: z3-symbolic-re-transform
description: "Solve obfuscated per-byte flag checks with Z3 bitvectors."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux]
metadata:
  hermes:
    tags: [ctf, reverse-engineering, z3, symbolic]
---

# Z3 Symbolic Solving of Obfuscated Transform Chains

Use when a stripped binary compares input against an encrypted blob and the
check is a chain of per-byte arithmetic (xor/add/mul/shift) with a rolling
state that depends on all previous bytes — too tangled to invert by hand.

## Workflow

1. Locate the compare: `objdump -d` and grep for the rodata blob address
   (the `memcmp`/`cmp` source operand). Dump `.rodata` to extract the blob.
2. Read the check function: identify the key constants (often in `.data`),
   the per-byte loop, and any chained state variable.
3. Model EXACTLY in Z3 bitvectors — every op must match the asm widths:

```python
from z3 import *
N = 55                       # flag length (blob size)
c = [BitVec(f"c{i}", 8) for i in range(N)]

# chained state (32-bit), e.g.  S = se(c[i]) ^ ((K^0x7F) | (S ^ 0x5E))
state = BitVecVal(0xDEADBEEF, 32)
for i in range(N):
    state = SignExt(24, c[i]) ^ ((K ^ 0x7F) | (state ^ 0x5E))

for i in range(N):
    b = c[i]
    t = (b ^ k1) + 3                                  # 8-bit ops wrap mod 256
    t = ((t * k2) - 13) ^ 0xA5                        # mulb = 8x8 -> low byte
    t = ((k3 + ZeroExt(24, t)) ^ (k3 >> 8)) + 7       # 32-bit ops
    t = (t ^ ZeroExt(16, k4)) + (ZeroExt(16, k4) >> 8)
    t = (t ^ 0x3C) & 0xFF
    s.add(Extract(7, 0, t) == BLOB[i])

s.add(c[0] == ord('E'), c[1] == ord('Q'), c[2] == ord('C'),   # flag prefix
      c[3] == ord('T'), c[4] == ord('F'), c[5] == ord('{'),
      c[N-1] == ord('}'))
for i in range(N):
    s.add(c[i] >= 0x20, c[i] <= 0x7E)                 # printable sanity
```

4. Solve, then ALWAYS verify: pipe the recovered flag into the real binary
   and confirm it prints "Correct".

## Pitfalls

- Z3 sort mismatches: `& 0xFF` does NOT narrow a BitVec — use
  `Extract(7, 0, expr)` for low byte; keep every op's width explicit.
- `movzbl` = ZeroExt, `movsbl`/`cbtw` = SignExt (sign-extension changes the
  value for bytes >= 0x80 — getting this wrong makes the model UNSAT).
- `mulb` (8x8 -> 16) then truncate: `(a*b) mod 256` equals 8-bit `a*b` in Z3;
  but a 32-bit `imul` followed by `^const` then truncate is NOT the same as
  truncating before the xor — model the full width, truncate last.
- Loop keys often depend only on the LAST byte (they are overwritten each
  iteration); only final values reach the transforms.
- Constants hide in `.data` (e.g. `5a c3 00 00 ef be ad de ce fa` =
  0x5a, 0xc3, 0xdeadbeef, 0xface). Dump `.data` before modeling.
- If UNSAT with prefix+printable constraints, relax stepwise (printable
  first, then prefix) — a wrong width assumption is the usual cause.
