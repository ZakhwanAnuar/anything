---
name: crlf-header-injection
description: "CRLF header injection through user-controlled header names."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux]
metadata:
  hermes:
    tags: [web, http, ctf, header-injection, crlf, response-splitting, python, flask]
---

# CRLF Header Injection Through User-Controlled Header Names

Use when a web app builds a response header NAME from user input
(e.g. `headers['Protection-' + name] = '1'`) and/or has a sanitizer that
blocks metacharacters but applies URL-decoding afterwards. Proven on EQCTF
"Protecc" (265, Easy): single injectable header had to become four
(`Protection-RCE`, `Protection-Secret`, `admin: true`) to win a verifier.

## Core pattern
If user input lands in a header NAME, embed `\r\n` to add whole new header
lines. `headers['Protection-' + name]` with
`name = "RCE: 1\r\nProtection-Secret: 1\r\nadmin: true\r\ndummy"` produces:
```
Protection-RCE: 1: 1        (app appends ": 1" at the very END of the line)
Protection-Secret: 1
Admin: true
dummy: 1                    (absorbs the trailing ": 1")
```

## The three traps (each cost debugging time)
1. **Filter-with-late-unquote bypass**: if a sanitizer checks the RAW param for
   `:`/`admin`/`true` and THEN calls `unquote()`, percent-encode the blocked
   tokens (`:` → `%3a`, `t` → `%74`); the app decodes them itself. Mixed-case
   `Admin` also slips blocklists that only check exact lowercase/uppercase
   substrings. Count DECODE HOOPS: Flask decodes the param once per hop, the
   filter unquotes again — the value you finally send may need double/triple
   encoding. Verify each layer with `unquote()` in python.
2. **http.client parser chokes on a colon-less first line**: the app appends
   `: 1` to the END of the whole header string, so an injection starting with
   `RCE\r\n...` yields a first line `Protection-RCE` with NO colon — the
   parser (email-based) swallows all following lines. Start the injection with
   a COMPLETE header (`RCE: 1`) so every line is valid.
3. **Exact value checks**: `adminCheck == 'true'` is case-sensitive — encode
   the first char (`%74rue`) or keep the value lowercase; case tricks work on
   header NAMES (case-insensitive) but not on string-compared VALUES.

## Verify locally BEFORE the remote
Replicate the app locally and test the FULL chain the way the victim client
will: (a) raw socket dump — see the true bytes (curl's parser hides the
mangled block); (b) `requests.get(...).headers.get(...)` — what the verifier
actually sees. The colon-less-first-line bug only shows up in (b).

## Pitfalls
- Werkzeug/Flask dev server writes CRLF header keys RAW to the socket
  (send_header does no validation) — if curl shows nothing, check raw bytes;
  the drop may be the client parser, not the server.
- Single-threaded dev servers (`app.run()` threaded=False) deadlock on
  internal self-requests (app → requests.get to itself). `flask run` handled
  it fine. When testing locally, use a separate-process client, and expect the
  remote (deployed differently) to behave differently.
- requests/http.client header parsing differs from curl's — always test with
  the same client library the challenge uses.
