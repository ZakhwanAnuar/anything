---
name: collatz-poly-xor-inversion
description: "Use when a Collatz sequence is poly-XOR'd to a polynomial."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux]
metadata:
  hermes:
    tags: [ctf, crypto, collatz, polynomial, xor, sage]
---

# Collatz Sequence -> Poly XOR Inversion

Use when a challenge generates a Collatz (or similar iterative) sequence from the
flag integer, wraps it into polynomials mod small moduli, XORs coefficients, and
prints the result as a polynomial (e.g. Sage output like `5*x^3759 + x^3758 + ...`).

## Attack pattern

1. **Understand the transforms.** Source typically does:
   - `clist` = sequence values (stops at 1; last elements are always `..., 8, 4, 2, 1`).
   - `p1 = poly(clist, 6)`: coeff of x^i = `clist[L-1-i] mod 6`.
   - `p2 = poly(clist[-3:]*(L//3), 6)`: coefficients repeat the tail `[4,2,1] mod 6`.
   - `s[i] = p1.coeffs[::-1][i] ^^ p2.coeffs[::-1][i]` (int XOR of mod-6 residues).
   - Output = `poly(s, 10)`: printed coeff at degree d = `s[L-1-d]`.

2. **Extract residues.** For each printed degree d:
   `clist[L-1-d] mod 6 = printed_coeff[d] ^^ pattern[(-1-d) mod 3]`, `pattern=[4,2,1]`.
   (XOR is self-inverse; zero coefficients in the printed poly mean the XOR was 0.)

3. **Infer length mod 3.** `len(p1.coeffs) == len(p2.coeffs)` forces `L % 3 == 0`.
   If the printed poly has D+1 slots, the unknown head length `k = L-(D+1)` satisfies
   `k % 3 == 2`. For missing head positions, `s[i]=0` => residue = `pattern[i mod 3]`
   cycling `[2,4,1]` going backwards.

4. **Backward reconstruction** from `clist[L-1] = 1`:
   - residue even -> `clist[i] = 2*clist[i+1]`
   - residue odd  -> `clist[i] = (clist[i+1]-1)/3` (must divide evenly)
   - assert `clist[i] % 6 == residue` each step.
   Then from `clist[0]`, the flag int is `m = 2*clist[0]` (m even) or `(clist[0]-1)/3`
   (m odd); try both, check flag format/bytes.

5. **Verify** by running the original transform forward on the recovered flag and
   comparing to the output file — must match exactly.

## Pitfalls

- `coefficients()` in Sage returns only NONZERO coefficients; you must map printed
  degrees to sequence positions using the polynomial construction order (reversed).
- The Collatz tail is always `..., 4, 2, 1` — this fixes the p2 pattern.
- Leading zero XOR coefficients are omitted in the printed polynomial; the head
  length `k` is unknown — search `k % 3 == 2` upward until the flag validates.
- Use Python int XOR (`^`), not mod-6 arithmetic, for the residue extraction.
- Verify forward after solving; wrong length assumption gives garbage bytes.
