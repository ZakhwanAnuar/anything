# Verified state — 2026-10-19

Branch codex/machine-protection, changes currently uncommitted. Do not re-report
historical findings fixed by d0aebcf, or the watcher/Windows import defects now
fixed by this branch. Source and acceptance tests take precedence over old skill
sections.

## Verification

- 109 ordinary tests pass; two native tests are explicitly ignored there.
- Both native tests pass in an isolated, network-less QEMU/KVM VM with Linux
  7.2.9. Benign execution/read controls pass. Marked execution gets EPERM before
  a marker is created. EICAR opens in new nested directories are blocked.
  Oversized inputs are denied; non-Unicode names cannot kill the JSON logger;
  native notifications cover new nested directories. No polling fallback.
- Linux all-target Clippy and x86_64-pc-windows-gnu all-target Clippy pass with
  warnings denied; fmt and release build pass. Windows execution/linking and
  policy enforcement are unverified.
- Boot unit syntax checked using a temporary copy pointing to the built binary.
- Host protection has NOT been activated. This session lacks passwordless sudo.

## New APIs and limits

- protect.rs: ProtectionScanner, LinuxProtector, ProtectionDecision, Action.
- scan.rs: ScanEngine compiles once, scan_handle scans the held descriptor and
  checks metadata before/after; old scan_file/scan_bytes API retained.
- fanotify.rs: shared mount marks + canonical root filters, RAII event ownership,
  overflow/version/length errors, permission response + default-deny on drop.
- protect embeds all 16 capability hunts; watch/scan remain detection-only and
  use their existing explicit --rules behavior. 28 behavior rules still need
  manually supplied JSONL: there is no live behavioral collector yet.
- protect uses a dedicated permission reader so scanning does not stall unrelated
  mount opens. Queue capacity 64; overflow denied with aggregate audit counts.
- This is a scoped file-content gate, not whole-machine/tamper-resistant EDR.
  Existing handles/mappings, new mounts and aliases outside roots remain gaps.
  Linux allows outstanding permission events when the daemon dies. No automatic
  quarantine or ransomware rollback is wired. Representative detection rates,
  false positives and long-running performance remain unmeasured.

Read docs/PROTECTION.md for deployment and exact policy before changing this.
