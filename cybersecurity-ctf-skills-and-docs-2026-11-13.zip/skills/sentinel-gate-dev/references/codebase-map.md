# Sentinel Gate — module and API map

Reading aid only: re-verify signatures with grep before coding against them. `cargo doc` in the repo is the other source of truth. Re-read this after any refactor lands — it went stale once already (nine modules missing).

## Binary surface (src/main.rs)

Commands: `scan`, `request`, `verify`, `quarantine`, `restore`, `list`, `snapshot`, `rollback`, `dissect`, `author`, `behavior`, `fim`, `watch`, `protect`.
Exit codes: scan 0 clean / 10 detection / 20 inconclusive; behavior and fim 10 when there is anything to look at (severity high+ for behavior, any alert for fim).

## Library modules (crate `sentinel-gate`)

- `scan.rs`: `read_bounded`, `scan_file`, `scan_bytes` -> `ScanReport` {schema_version, sha256, size_bytes, file_type, verdict, execution_authorization, findings, inspection}. `Finding` {id, source, classification: information|suspicious|test|malware|error, message}; `Inspection` carries entropy + `ExecutableMetadata` (sections, wx regions). Its PE/ELF header inspector uses `checked_add` throughout — keep it that way.
- `dissect.rs` (largest module): `dissect_file` -> Dossier. `PeDetails` (authenticode_bytes, tls_callbacks, rich_header, overlay_bytes, imports per DLL, exports, debug_pdb_path), `ElfDetails` (interpreter, needed_libraries, exec-stack), `StringsSummary`, `Iocs`. Capability inference and the triage score live here — add file-evidence capabilities here. Its `PeView`/`ElfView` parsers read attacker-controlled headers: bound every file-supplied offset before arithmetic on it.
- `behavior.rs`: `Event` {ts, kind, pid, ppid, image, target_pid, target_image, cmdline, path, name, domain, dst_ip, dst_port, bytes_out, key, value, access, signed, story_id}; `BehaviorRule` {id, title, severity, mitre[], scope, window_secs, steps[], enabled, indicator_type, min_engine}; `Step` {kind, any[], none[], count}. `parse_trace` consumes JSONL, `default_rules()` embeds `rules/behavior/*.json`, `load_rules(dir)` reads + bounds-checks + parses, `analyze` -> `BehaviorReport`.
  - Matching is precomputed: `analyze` builds one lowercase haystack per event (`Event::haystack`) and `lowercased_needles` per rule, then `step_hits` lists the positions each step matches so `evaluate_sequence` advances with a binary search. Evaluation is linear in a process's event count — do not reintroduce a forward rescan from every start position.
- `content.rs`: the declared-schema validator. `validate_rule_file`, `parse_external_rules`, `ContentValidator`, `FieldSpec`/`FieldKind`. `load_rules` calls it, so an external rule file is refused before it reaches the engine.
- `storyline.rs`: `Storyline::build`, `storyline_for`, `lineage`, `evidence_chain`, `analyze_with_lineage` -> `StorylineReport` {report: BehaviorReport, findings: [StorylineFinding]}. Wired into `sentinel-gate behavior`.
- `schema.rs`: `CanonicalEvent` (dotted keys, `deny_unknown_fields`), `CANONICAL_ALIASES`, `canonical_for_source`, `required_fields`, `parse_utc_timestamp`, `to_behavior_event`. No collector consumes it yet.
- `fim.rs`: `build_baseline`, `diff_scan` -> `FimAlert` {file_added|file_modified|file_removed}, `FimOptions` {ignore, max_hash_bytes, max_files}. Sidecar is JSON; ignore globs match relative to the root.
- `onaccess/`: `mod.rs` (`AccessEvent`, `ExclusionSet`, `glob_match` — also used by `fim.rs`), `watch.rs` (`WatchEngine`, `PollingSource`, `ProcessedEvent`, `SOURCE_WAIT`), `cache.rs` (`ScanCache`, `CacheKey`, insertion-ordered eviction), `queue.rs` (`BoundedQueue`, `OverflowAudit`), `fanotify.rs` (`LinuxFanotifyWatcher`, notification-only `FAN_CLASS_NOTIF`).
- `author.rs`: `author_rule` / `author_rule_from_bytes` -> `AuthorReport`; gate = compile + self-match + zero benign matches, and the two attempts (literals+atoms, then atoms only) run through one closure builder. Classification is always `hunt`.
- `vault.rs` (**private module**: `mod vault;` in lib.rs): the shared private-vault primitives — `absolute_leaf`, `read_bounded`, `open_regular`, `write_private`, `private_directory`, `validate_private`, `secure_file`, `same_file`, `reject_hardlinks`, `sync_directory`, `random_fill`, `sha256_hex`, plus the `seal_record`/`open_record` XChaCha20-Poly1305 envelope and the `VaultRecord` trait. Also the crate's only `unsafe` (libc `geteuid`, kernel32 `GetFileInformationByHandle`), each with an item-level allowance.
- `quarantine.rs`: `quarantine_file`, `restore_file`, `list_records`; `QuarantineRecord` implements `VaultRecord`. Magic `SGQ1`, extension `.sgq`.
- `rollback.rs`: `BackupStore` {open, mark_suspicious, snapshot, restore, list}; `BackupRecord` implements `VaultRecord`. Magic `SGR1`, extension `.sgr`. Snapshot key is `SHA-256("path@mtime")`.
- `approval.rs`: `ApprovalRequest` — advisory only; `write_new`, `verify_artifact`; never grants execution.
- `src/bin/prevention-fixture.rs`: harmless fixture binary for the Phase 3 blocking acceptance test.

## Rules

- `protect.rs`: ProtectionScanner compiles embedded capability hunts plus local rules once; decides on held descriptors. LinuxProtector uses a dedicated fanotify reader, 64-request bounded queue and explicit denial of detections/errors. No metadata cache, no automatic quarantine, no polling fallback. Mount marks cover nested directories; filtering limits policy to canonical roots. Normal host activation needs CAP_SYS_ADMIN.
- `scan.rs`: ScanEngine {new, scan, scan_handle} reuses compiled rules; descriptor scanning checks file size, mtime and Unix ctime before/after the scan. The existing scan_bytes/scan_file wrappers remain evidence-only.
- Native enforcement tests in tests/protection.rs are ignored in ordinary runs and must be executed explicitly in a privileged disposable VM; they never fall back to polling. A boot template is in deploy/sentinel-gate-protect@.service. Read docs/PROTECTION.md before enabling it.

- `rules/modern-malware.yar` — opt-in capability hunt pack.
- `rules/test-detections.yar` — builtin harmless fixtures used by tests.
- `rules/behavior/*.json` — six packs: credential-theft, ransomware, defense-evasion, execution-chains, persistence, remote-access (28 rules). Every field used in a pack must also be declared in `content.rs`.
- `rules/generated/` — only analyst-promoted auto-authored rules land here.

## Tests & layout

- Unit tests are inline (`#[cfg(test)]`) in most modules; integration tests are `tests/{scan,approval,fim,onaccess,rollback,storyline,content_validate}.rs`.
- Windows PowerShell tooling under `windows/` (WDAC policy create/sign/install/status) with tests in `windows/tests/`. The Windows build is unverified — only `x86_64-unknown-linux-gnu` is installed on this host.
- Full gate: `cargo test && cargo clippy --all-targets -- -D warnings && cargo fmt --check`.
