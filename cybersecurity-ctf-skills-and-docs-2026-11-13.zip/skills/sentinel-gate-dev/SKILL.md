---
name: sentinel-gate-dev
description: Use when working on the user's Sentinel Gate AV project.
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [security, rust, av, edr]
    related_skills: [multi-target-research]
---

# Sentinel Gate development

## Verified correction — 2026-10-19

Commit `d0aebcf` fixes the historical ELF overflow, quadratic matcher, cache
eviction, vault duplication/Windows ACL drift, FIM/content/Storyline wiring,
inventory corruption handling and author retry findings described below. Do not
report those older bullets as open defects. `references/audit-findings.md` now
records current evidence and takes precedence over the historical sections.
Current branch `codex/machine-protection` adds the Linux `protect` permission
gate, shared mount-based recursive notifications, descriptor ownership/overflow
handling and Windows platform gates. 109 ordinary tests and two explicit native
tests pass; the native tests ran in an isolated QEMU/KVM guest with the host's
7.2.9 kernel, not via polling. Linux and Windows all-target Clippy pass with
warnings denied. Host activation still needs administrator access; sudo is not
available without a password in this session. See docs/PROTECTION.md for the
scoped deny policy and shutdown/mount/memory-only limits.

## When to Use

Any task touching the Sentinel Gate repo — extending detection, adding sensors or collectors, porting mechanisms from other AV products, updating its docs or rules, or asserting anything about its build/test state. Skip for unrelated Rust work.

## Project facts

- Repo: `/home/kubesame/Documents/Personal Project/MY OWN ANTIVIRUS/` — always quote the path; it contains spaces and capitals.
- Rust edition 2024, MSRV 1.93, crate `sentinel-gate`; detection core is yara-x (pinned to an exact version — do not bump casually).
- Top-level docs are the project's law — read `docs/` first each session: VISION (thesis), CLONE-MAP (what to clone from other products + legality boundary), THREAT-COVERAGE (gap matrix), ROADMAP (phases with acceptance tests), LAB (trace schema).
- Read `references/codebase-map.md` in this skill for the module/API surface before writing code against it, and re-verify via grep — the map is a reading aid, not a contract.
- Read `references/audit-findings.md` for the open, verified defects found by whole-repo audit (file:line, the concrete case, the fix) before starting work on `dissect`, `rollback`, `behavior`, `fim`, `content` or `storyline`.
- Both Linux and x86_64-pc-windows-gnu targets are installed. Windows all-target compilation/lint checks pass; Windows linking, execution and WDAC enforcement remain unverified.

## Always-on product gates (non-negotiable)

- A scan is never permission to run: every output type carries `execution_authorization` and it is always `not_granted`.
- Fail closed: errors, timeouts, oversized files, unreadable files produce verdict `Inconclusive`, never clean/`NoDetection`.
- Quarantine accepts only confirmed detections (or the explicit `--allow-test` fixture); restore never grants execution either.
- Auto-authored rules are classification `hunt`, never `malware`, and must compile, match their own sample, and match zero benign-corpus files before being written.
- The crate denies unsafe code except justified item-level allowances in vault, onaccess identity and fanotify boundaries; each needs a SAFETY note. Prefer safe Rust elsewhere.
- Bounded work everywhere: cap file size, string counts, trace sizes; a hostile header must not cause unbounded allocation.
- Never claim prevention where the delivered layer is detection-only; THREAT-COVERAGE marks a technique covered only when a test proves a rule fires.

## Adding detection coverage (the loop)

1. Dissect the sample or read the trace; identify what evidence actually exists (file bytes vs event sequence).
2. Add the cheapest durable layer, in this order: capability check in `src/dissect.rs` if evidence is in-file; YARA rule in `rules/modern-malware.yar` if the bytes are distinctive; behavior rule in `rules/behavior/*.json` if observable in events.
3. Add a firing test (synthetic sample or JSONL trace) AND a benign lookalike that must NOT fire.
4. Run the benign corpus through any generated rule; a rule that cannot pass is not ready.
5. Record provenance (sample SHA-256, date, confidence, explicit non-claims) and update THREAT-COVERAGE.md only after a test proves it.

## Porting mechanisms from other AV/EDR products

- Closed-source products (Defender, Bitdefender, Kaspersky, ESET, SentinelOne, CrowdStrike, Malwarebytes): documentation-level teardown only — never disassemble or patch their binaries. Map to the CLONE-MAP.md matrix.
- Open-source engines (ClamAV, Falco, Tetragon, Wazuh, YARA-X, Sigma): source-level mechanism teardown; reimplement in Rust, watch licenses (Apache-2.0 vs GPLv2).
- Every clone maps to a ROADMAP phase with an acceptance test; a clone with no acceptance test is scope creep.

## Shared vault (both stores)

`src/vault.rs` is a **private** module (`mod vault;`) holding the file, privacy and
crypto primitives `quarantine.rs` and `rollback.rs` both need: `absolute_leaf`,
`read_bounded`, `open_regular`, `write_private`, `private_directory`,
`validate_private`, `secure_file`, `same_file`, `reject_hardlinks`,
`sync_directory`, `random_fill`, `sha256_hex`, plus the `seal_record`/`open_record`
envelope and the `VaultRecord` trait.

- A third store = implement `VaultRecord` (`record_id`, `record_len`,
  `record_sha256`) and call `seal_record`/`open_record` with its own magic. Never
  copy the envelope, the unix mode call or the Windows ACL helper: the last copy
  silently lost the ACL check and the `cfg(unix)` gate, which broke the Windows
  build and left the vault world-readable there.
- Anything unix-only (`Permissions::from_mode`) goes inside `vault::secure_file`,
  which has cfg(unix)/cfg(windows) bodies.
- A new `unsafe` block — including one inside `#[cfg(windows)]` — needs its own
  `#[allow(unsafe_code)]` and a SAFETY note: the crate is `#![deny(unsafe_code)]`
  and Linux never compiles the Windows branch that would have caught the lint.

## Coupled declarations (change one, change the other)

- Adding a field to `BehaviorRule` or `Step` means declaring it in `content.rs`'s
  `rule_validator`/`step_validator` with a kind and a bound, or every external rule
  file fails with "undeclared field". The embedded packs go through
  `parse_rule_file` and are not validated, so only `behavior --rules <dir>` breaks.
- `Event::haystack()` is the one place deciding which event fields a rule's
  `any`/`none` needles can match. New searchable field = add it there, lowercased.
- Rule matching is precomputed (`lowercased_needles` + `step_hits` + binary search in
  `evaluate_sequence`), so evaluation stays linear in one process's event count. Do
  not reintroduce a forward rescan from every start position: that shape measured
  quadratic (0.07s / 0.29s / 1.08s / 4.18s for 1k / 2k / 4k / 8k events).

## Parsers and hostile input

- `dissect.rs`'s PE/ELF parsers read attacker-controlled headers. Bound a
  file-supplied offset against `data.len()` *before* arithmetic on it: `entry + width`
  on a crafted `u64::MAX` field overflowed and panicked the scanner.
- `cargo test` and dev builds run with overflow checks on; release wraps silently. So
  "it worked in release" is not a safety claim, and a hostile-input test belongs in the
  debug profile. The truncation sweeps in `dissect.rs`/`scan.rs` are the model.

## Editing this repo

- After a long session, `write_file` refuses a file that was read earlier and not
  re-read since ("stale"). Re-read it, or use `patch` — a matching span is enough.

## Rollback store — snapshot-on-suspicious-access (Phase 3)

Clone of Bitdefender's ransomware remediation and Kaspersky's "backup copies when a suspicious process opens a file" (CLONE-PLAN Task 3.1), userspace only. Lives in `src/rollback.rs`.

Trigger: the behavioural engine flags a pid as suspicious.

Steps:
1. `BackupStore::open(&vault, create)` — opens or creates the private vault beside quarantine's; shares the per-vault `vault.key` (one crypto path, XChaCha20-Poly1305 envelope).
2. `store.mark_suspicious(pid)` — only flagged pids trigger snapshots; benign pids never do.
3. `store.snapshot(&path, mtime_unix, pid)` — snapshots current bytes keyed by `SHA-256("path@mtime")`; reuses the existing entry when the same path+mtime was already snapshotted. Returns `None` for non-suspicious pids.
4. `store.restore(&id, &destination)` — restores byte-identical content to an explicit new path outside the vault; the encrypted entry is never removed, so a failed restore leaves the original bytes recoverable.

Gates (non-negotiable):
- Restoration never grants execution; it only returns preserved bytes.
- The vault must be a real directory, owned by this uid, mode 0700 (`validate_private`); `BackupStore::open(&vault, false)` fails on a nonempty vault with no key.
- Reject symlinks, directories, and nonregular files (`open_regular` with `O_NOFOLLOW`).
- Append-only store: `restore` never removes an entry; `list` skips corrupt entries rather than failing the whole store.
- Max record 512 MiB, max metadata 64 KiB — bounded allocation on hostile input.

Pitfalls:
- `//!` inner doc comments belong only at module top; putting one mid-file on an item triggers `E0753: expected outer doc comment` — use `///`.
- The crate is `#![deny(unsafe_code)]`; the single libc call (`geteuid` in `validate_private`) needs item-level `#[allow(unsafe_code)]` with a SAFETY note, matching `quarantine.rs`.
- Remove unused helpers (e.g. `open_vault_dir`) or annotate `#[allow(dead_code)]` for platform-gated ones like unix-only `secure_file` — `-D warnings` fails on dead code.
- `BackupRecord` field is `size`, not `bytes` — `read_record` validates `record.size`.
- `BackupStore::open` takes `&TempDir` in tests; pass `&dir`, not `dir`.
- `write_private` calls `fs::Permissions::from_mode(0o600)` with no `#[cfg]` gate while the `PermissionsExt` import sits inside a `#[cfg(unix)]` block, so `rollback.rs` does not compile for a Windows target even though `lib.rs` registers it unconditionally. Route mode changes through a `secure_file()` with separate cfg(unix)/cfg(windows) bodies, as `quarantine.rs` does.
- `validate_private`'s Windows body is `Ok(())` — it accepts a vault with inherited ACLs, where quarantine's Windows body runs a PowerShell ACL check. What gets stored here is a copy of the user's documents.
- rollback.rs duplicates 245 of its 427 non-blank lines from quarantine.rs (12 shared helpers, including a byte-identical `read_bounded`), and the copies have already drifted — the two cfg bugs above are that drift. Extract a shared vault module rather than writing a third copy.

CLI: `snapshot <file> <mtime> <pid> --vault <dir>` and `rollback <id> --vault <dir> --destination <path>`, both emitting `execution_authorization: not_granted`.

## Wiring check — before calling anything delivered

A module that is implemented and unit-tested is not shipped until the binary can reach it. Grep the
CLI surface before writing a status report or claiming a phase is done:

```bash
cd "/home/kubesame/Documents/Personal Project/MY OWN ANTIVIRUS" && grep -n "sentinel_gate::" src/main.rs
```

These pass their tests but no entry point calls them — never describe them as delivered:

- `src/fim.rs` (367 lines): no `fim` subcommand exists; reachable only from `tests/fim.rs`.
- `src/content.rs`: `validate_rule_file` / `parse_external_rules` are called by nothing. `behavior --rules <dir>` reaches rules through `behavior::load_rules` → `parse_rule_file`, which skips the validator entirely.
- `src/storyline.rs`: `main.rs` calls `behavior::analyze`, never `analyze_with_lineage`, so product findings carry no lineage.
- `src/schema.rs` (828 lines) and the one-line `src/collector/mod.rs`: referenced by nothing outside themselves.

Both fixes are small: in the `behavior` command swap `analyze` for `analyze_with_lineage`; in
`parse_rule_file` call `validate_rule_file(&source)` first.

## Parser and hostile-input pitfalls

- `src/dissect.rs` primitive readers use bare `offset + N` (`read_u16`/`read_u32`/`read_u64`, and the `needed_libraries` walk), unlike `scan.rs`, which guards with `checked_add`. An ELF whose `.dynamic` section header carries `sh_offset = u64::MAX` panics the debug binary at `src/dissect.rs:1817` ("attempt to add with overflow", exit 101), and in release silently returns an empty library list instead. Fix with `checked_add` plus a section-offset check against `data.len()`.
- Land any hostile-input fix as a test beside the existing hostile-PE test in `dissect.rs`. That test sweeps truncated PE headers only, which is why the ELF case survived; the equivalent `scan.rs` test passes because that parser uses `checked_add`.
- The behaviour engine's forward walk is O(N^2) in one process's events whenever a later step shares an earlier step's kind (`behavior.rs` `evaluate_sequence`). Measured with one rule: 0.07s at 1k events, 0.29s at 2k, 1.08s at 4k, 4.18s at 8k. Do not author same-kind consecutive steps in a pack, and do not quote a short-trace timing as the engine's speed.

## Quality gate before claiming done

```bash
cd "/home/kubesame/Documents/Personal Project/MY OWN ANTIVIRUS" && cargo test && cargo clippy --all-targets -- -D warnings && cargo fmt --check
```

Hermes shells do NOT have cargo on PATH (no `~/.cargo/bin`). Export the rustup shim bin — this is
the wrapper, so it still honours `rust-toolchain.toml`:
`export PATH="/home/linuxbrew/.linuxbrew/opt/rustup/bin:$PATH"`
You can also prepend `/var/home/kubesame/.rustup/toolchains/<version>-x86_64-unknown-linux-gnu/bin`,
but that connects cargo directly and bypasses the pin.

## Docs inventory

`docs/TEARDOWN-{consumer-av,enterprise-edr,opensource-linux,crowdstrike-sentinelone}.md` are the
research teardowns (14 products, 146+ cited sources); `docs/CLONE-PLAN.md` is the task-level build
plan derived from them (five cloneable pillars, phase-gapped tasks with acceptance tests, explicit
non-goals). Research-subagent caution: one teardown agent also edited CLONE-MAP.md and wrote a
teardown into repo docs unsolicited — re-read any parent-read file after delegation before patching.
