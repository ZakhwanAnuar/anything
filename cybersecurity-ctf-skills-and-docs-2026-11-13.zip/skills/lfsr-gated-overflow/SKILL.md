---
name: lfsr-gated-overflow
description: Use when a pwn CTF binary exposes an LFSR/PRNG leak command and gates a stack overflow behind a predicted token or frame value.
---

# LFSR-Gated Overflow

Use this workflow when a service leaks bits or state from a predictable PRNG and later requires a matching token before reaching an overflow.

1. Identify protocol commands and their exact integer endianness.
2. Check for an over-read command near PRNG state or libc globals; a bounded “preview/glimpse/beacon” command may leak more than user-facing text.
3. Reconstruct the PRNG transition exactly, including output bit order, before triggering the gated command.
4. Place the predicted token at the checked payload offset, then continue the payload to the saved return address.
5. If the binary has no PIE and no canary but NX is enabled, use leaked libc pointers plus libc gadgets for ret2libc.
6. If the binary lacks register-pop gadgets, inspect internal read/write helpers for staging and pivot primitives.

SunCTF “Dreams Lift Us Up” pattern:

- `G <u16>` over-read leaked `.bss`: `stdout` at offset `0x18`, LFSR state at offset `0x20`.
- LFSR output was the old LSB each step; next state was `state >> 1`, XOR `0xad93d23594c935a9` when the old LSB was `1`.
- `L <u16>` compared bytes at payload offset `0x40` with the next 64 output bits, then returned through saved RIP at offset `0x48`.
