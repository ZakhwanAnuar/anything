---
name: huntress-expansion-pack
description: Solve the Huntress CTF 2026 AI Arena Expansion Pack challenge, including its timed two-set Mastery mode, from the player's assigned evidence.
---

# Huntress Expansion Pack

Use this skill for **Expansion Pack** on Huntress CTF 2026 AI Arena. The lesson is `new-lesson-d08b78a8`; the Game Master challenge is `script-analysis-day-03-batch-expansion`. The mode suffixes are `/time_trial` and `/mastery`. Other Huntress challenges have different artifacts and answer contracts.

## Work from the player's attempt

1. Inspect the authenticated lesson and Game Master `status`. Check which of Single Solve, Time Trial, and Mastery are already correct before starting anything. The CourseStack lesson questions are the final score record.
2. Use the player's own paired Game Master bearer. Keep it out of prompts, logs, skill files, and final replies. If a camofox tab is at sign-in, reuse the player's existing authenticated browser session through its cookie import route rather than requesting a password.
3. Read the live `questions[]` and `answer_ids`; they are the contract for this attempt. Fetch the assigned evidence after `start`. Mastery has two deliveries: `delivery=0` for `set1.*` answers and `delivery=1` for `set2.*`. Files are assigned per attempt; a static lesson download or another mode's pack will yield wrong values.
4. Extract the AES ZIPs using a tool that supports WinZip AES, such as `7z`. The observed password was `infected`; confirm it against the current challenge context. Analyze the Batch, JScript, and PowerShell specimens as data. Do not run the specimens.
5. The first timed `start` may expire while you analyze the freshly assigned files. Prepare the exact answer strings, then open a `retry` window and submit under the exact answer IDs from the current status. A Mastery submission uses both `set1.` and `set2.` prefixes in one answer map. When the Game Master reports `accepted` with `remaining`, retain accepted fields and correct the remaining fields in a later `retry` window on the same attempt. Rate limits and the 7-second Mastery timer make manual per-field work unreliable.
6. Finish only after the Game Master reports `CORRECT` and CourseStack marks the corresponding dynamic question `correct`. Refresh the camofox page to confirm the score.

Read [Game Master API and evidence analysis](references/expansion-pack.md) for request shapes, artifact decoding, and known traps.
